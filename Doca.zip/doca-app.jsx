// ─── AdwToast ─────────────────────────────────────────────────────────────────
const AdwToast = ({ message, onDone }) => {
  const { useEffect, useState } = React;
  const [out, setOut] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setOut(true), 2600);
    const t2 = setTimeout(onDone, 2900);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);
  return (
    <div className="adw-toast-overlay">
      <div className={`adw-toast${out ? ' adw-toast--out' : ''}`} role="alert" aria-live="assertive" aria-atomic="true">
        <span className="adw-toast__title">{message}</span>
      </div>
    </div>
  );
};

// ─── Dashboard ────────────────────────────────────────────────────────────────
const Dashboard = ({ containers, images, volumes, networks, onNavigate }) => {
  const { useState, useEffect } = React;
  const running = containers.filter(c => c.status === 'running').length;
  const paused  = containers.filter(c => c.status === 'paused').length;
  const stopped = containers.filter(c => c.status === 'stopped' || c.status === 'exited').length;
  const errored = containers.filter(c => c.status === 'error').length;

  const [sysCpu, setSysCpu] = useState(8.4);
  const [sysMem, setSysMem] = useState(42.1);
  const [sysDisk] = useState(61.3);

  useEffect(() => {
    const iv = setInterval(() => {
      setSysCpu(v => Math.max(2, Math.min(95, v + (Math.random() - 0.45) * 3)));
      setSysMem(v => Math.max(20, Math.min(90, v + (Math.random() - 0.5) * 0.8)));
    }, 2000);
    return () => clearInterval(iv);
  }, []);

  const MiniBar = ({ val, color }) => (
    <div style={{ height: 4, borderRadius: 2, background: 'var(--border-color)', overflow: 'hidden', marginTop: 4 }}>
      <div style={{ height: '100%', width: `${val}%`, background: color, borderRadius: 2, transition: 'width 0.8s ease' }}/>
    </div>
  );

  const StatCard = ({ label, value, color, onClick }) => (
    <div className="adw-stat-card" onClick={onClick} role="button" tabIndex={0}>
      <div className="adw-stat-card__value" style={{ color }}>{value}</div>
      <div className="adw-stat-card__label">{label}</div>
    </div>
  );

  return (
    <div className="adw-detail-scroll">
      {/* Container status row — 4 cols on desktop, 2×2 on mobile */}
      <div className="dash-grid-4">
        <StatCard label="Running" value={running} color="var(--success-color)" onClick={() => onNavigate('containers')}/>
        <StatCard label="Paused"  value={paused}  color="var(--warning-color)" onClick={() => onNavigate('containers')}/>
        <StatCard label="Stopped" value={stopped} color="var(--window-fg-color)" onClick={() => onNavigate('containers')}/>
        <StatCard label="Errors"  value={errored} color="var(--error-color)" onClick={() => onNavigate('containers')}/>
      </div>

      {/* Resources row — 3 cols always (compact enough) */}
      <div className="dash-grid-3">
        <StatCard label="Images"   value={images.length}   color="var(--accent-color)" onClick={() => onNavigate('images')}/>
        <StatCard label="Volumes"  value={volumes.length}  color="var(--accent-color)" onClick={() => onNavigate('volumes')}/>
        <StatCard label="Networks" value={networks.length} color="var(--accent-color)" onClick={() => onNavigate('networks')}/>
      </div>

      {/* Host resources + Recent events — side by side desktop, stacked mobile */}
      <div className="dash-grid-2">
        <div className="adw-prefs-group" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Host Resources</h3></div>
          <div className="adw-prefs-group__listbox" style={{ flex: 1 }}>
            {[
              { k: 'CPU',    v: sysCpu,  color: 'var(--accent-color)' },
              { k: 'Memory', v: sysMem,  color: 'var(--success-color)' },
              { k: 'Disk',   v: sysDisk, color: 'var(--warning-color)' },
            ].map(({ k, v, color }) => (
              <div key={k} className="adw-pref-row" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 4, padding: '10px 14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: '0.9375rem', color: 'var(--card-fg-color)' }}>{k}</span>
                  <span style={{ fontSize: '0.9375rem', fontWeight: 700, color: 'var(--card-fg-color)' }}>{v.toFixed(1)}%</span>
                </div>
                <MiniBar val={v} color={color}/>
              </div>
            ))}
          </div>
        </div>

        <div className="adw-prefs-group" style={{ display: 'flex', flexDirection: 'column', marginTop: 0 }}>
          <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Recent Events</h3></div>
          <div className="adw-prefs-group__listbox" style={{ flex: 1 }}>
            {EVENTS.slice(0, 5).map((e, i) => (
              <div key={i} className="adw-pref-row" style={{ gap: 8, padding: '10px 12px' }}>
                <span style={{ fontSize: '0.75rem', color: 'var(--card-fg-color)', opacity: 0.45, fontFamily: 'var(--font-mono)', flexShrink: 0 }}>{e.ts}</span>
                <span style={{
                  fontSize: '0.6875rem', padding: '2px 6px', borderRadius: 4, flexShrink: 0, fontWeight: 700,
                  background: e.action === 'start' ? 'rgba(38,162,105,0.12)' : e.action === 'stop' || e.action === 'die' ? 'rgba(192,28,40,0.1)' : 'var(--border-color)',
                  color: e.action === 'start' ? 'var(--success-color)' : e.action === 'stop' || e.action === 'die' ? 'var(--error-color)' : 'var(--card-fg-color)',
                }}>{e.action}</span>
                <span style={{ fontSize: '0.875rem', color: 'var(--card-fg-color)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.actor}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Sidebar rows ─────────────────────────────────────────────────────────────
const ContainerRow = ({ c, selected, onSelect, onAction }) => (
  <div className={`adw-action-row${selected ? ' selected' : ''}`} onClick={() => onSelect(c)}>
    <div className="adw-action-row__prefix" style={{ color: 'var(--card-fg-color)' }}>
      <Ico n="container" size={20}/>
    </div>
    <div className="adw-action-row__body">
      <span className="adw-action-row__title">{c.name}</span>
      <span className="adw-action-row__subtitle">{c.image}</span>
    </div>
    <div className="adw-action-row__suffix" onClick={e => e.stopPropagation()}>
      <StatusBadge status={c.status}/>
      {c.status === 'running'                                                    && <button className="adw-row-btn" title="Stop"    onClick={() => onAction('stop',    c)}><Ico n="stop"  size={15}/></button>}
      {(c.status === 'stopped' || c.status === 'exited' || c.status === 'error') && <button className="adw-row-btn" title="Start"   onClick={() => onAction('start',   c)}><Ico n="play"  size={15}/></button>}
      {c.status === 'running'                                                    && <button className="adw-row-btn" title="Pause"   onClick={() => onAction('pause',   c)}><Ico n="pause" size={15}/></button>}
      {c.status === 'paused'                                                     && <button className="adw-row-btn" title="Unpause" onClick={() => onAction('unpause', c)}><Ico n="play"  size={15}/></button>}
      <button className="adw-row-btn danger" title="Remove" onClick={() => onAction('remove', c)}><Ico n="trash" size={15}/></button>
    </div>
  </div>
);

const ImageRow = ({ img, selected, onSelect, onAction }) => (
  <div className={`adw-action-row${selected ? ' selected' : ''}`} onClick={() => onSelect(img)}>
    <div className="adw-action-row__prefix"><Ico n="img" size={20}/></div>
    <div className="adw-action-row__body">
      <span className="adw-action-row__title">{img.name}:{img.tag}</span>
      <span className="adw-action-row__subtitle">{img.size}{!img.inUse ? ' · dangling' : ''}</span>
    </div>
    <div className="adw-action-row__suffix" onClick={e => e.stopPropagation()}>
      <button className="adw-row-btn danger" title="Remove" onClick={() => onAction('remove', img)}><Ico n="trash" size={15}/></button>
    </div>
  </div>
);

const VolumeRow = ({ vol, selected, onSelect, onAction }) => (
  <div className={`adw-action-row${selected ? ' selected' : ''}`} onClick={() => onSelect(vol)}>
    <div className="adw-action-row__prefix"><Ico n="vol" size={20}/></div>
    <div className="adw-action-row__body">
      <span className="adw-action-row__title">{vol.name}</span>
      <span className="adw-action-row__subtitle">{vol.driver} · {vol.size}{!vol.inUse ? ' · unused' : ''}</span>
    </div>
    <div className="adw-action-row__suffix" onClick={e => e.stopPropagation()}>
      <button className="adw-row-btn danger" title="Remove" onClick={() => onAction('remove', vol)}><Ico n="trash" size={15}/></button>
    </div>
  </div>
);

const NetworkRow = ({ net, selected, onSelect, onAction }) => (
  <div className={`adw-action-row${selected ? ' selected' : ''}`} onClick={() => onSelect(net)}>
    <div className="adw-action-row__prefix"><Ico n="net" size={20}/></div>
    <div className="adw-action-row__body">
      <span className="adw-action-row__title">{net.name}</span>
      <span className="adw-action-row__subtitle">{net.driver} · {net.subnet}</span>
    </div>
    {net.name !== 'bridge' && net.name !== 'host' && net.name !== 'none' && (
      <div className="adw-action-row__suffix" onClick={e => e.stopPropagation()}>
        <button className="adw-row-btn danger" title="Remove" onClick={() => onAction('remove', net)}><Ico n="trash" size={15}/></button>
      </div>
    )}
  </div>
);

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const Sidebar = ({ tab, items, selected, onSelect, onAction, onAdd }) => {
  const { useState } = React;
  const [search, setSearch] = useState('');
  const [collapsed, setCollapsed] = useState({});

  const q = search.toLowerCase();
  const filtered = items.filter(item => {
    const name = item.name || '';
    const image = item.image || '';
    const id = item.id || '';
    return name.toLowerCase().includes(q) || image.toLowerCase().includes(q) || id.toLowerCase().includes(q);
  });

  const isSelected = (item) => selected &&
    ((item.id  !== undefined && selected.id   === item.id) ||
     (item.name !== undefined && selected.name === item.name && selected.id === undefined));

  const renderRow = (item) => {
    const key = item.id || item.name;
    const sel = isSelected(item);
    if (tab === 'containers') return <ContainerRow key={key} c={item}   selected={sel} onSelect={onSelect} onAction={onAction}/>;
    if (tab === 'images')     return <ImageRow     key={key} img={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
    if (tab === 'volumes')    return <VolumeRow    key={key} vol={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
    return                           <NetworkRow   key={key} net={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
  };

  // Compose grouping
  let content;
  if (tab === 'containers') {
    const groups = {};
    filtered.forEach(c => {
      const g = c.compose || '__ungrouped';
      if (!groups[g]) groups[g] = [];
      groups[g].push(c);
    });
    const names = [...Object.keys(groups).filter(g => g !== '__ungrouped').sort(), '__ungrouped'];
    content = names.map(g => {
      const gc = groups[g];
      if (!gc || gc.length === 0) return null;
      if (g === '__ungrouped') return gc.map(renderRow);
      const isCollapsed = collapsed[g];
      const allRunning = gc.every(c => c.status === 'running');
      const anyRunning = gc.some(c => c.status === 'running');
      return (
        <div key={g}>
          <div className="adw-compose-group" onClick={() => setCollapsed(s => ({ ...s, [g]: !s[g] }))}>
            <div style={{ color: 'var(--sidebar-fg-color)', opacity: 0.55, transition: 'transform 0.15s', transform: isCollapsed ? 'rotate(-90deg)' : 'none' }}>
              <Ico n="chevdown" size={16}/>
            </div>
            <Ico n="compose" size={14}/>
            <span className="adw-compose-group__label">{g}</span>
            <span className="adw-compose-group__count" style={{
              background: allRunning ? 'rgba(38,162,105,0.12)' : anyRunning ? 'rgba(229,165,10,0.14)' : 'var(--border-color)',
              color: allRunning ? 'var(--success-color)' : anyRunning ? 'var(--warning-color)' : 'var(--window-fg-color)',
            }}>
              {gc.filter(c => c.status === 'running').length}/{gc.length}
            </span>
          </div>
          {!isCollapsed && (
            <div style={{ paddingLeft: 12, display: 'flex', flexDirection: 'column', gap: 4 }}>
              {gc.map(renderRow)}
            </div>
          )}
        </div>
      );
    });
  } else {
    content = filtered.length === 0 ? <EmptyList tab={tab}/> : filtered.map(renderRow);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      {/* Search entry */}
      <div className="adw-search-entry">
        <span style={{ color: 'var(--sidebar-fg-color)', opacity: 0.55, display: 'flex', alignItems: 'center' }}><Ico n="search" size={16}/></span>
        <input
          placeholder={`Filter ${tab}…`}
          value={search}
          onChange={e => setSearch(e.target.value)}
          aria-label={`Filter ${tab}`}
        />
        {search && (
          <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--sidebar-fg-color)', opacity: 0.55, padding: 2, display: 'flex', alignItems: 'center' }}
            onClick={() => setSearch('')} aria-label="Clear filter">
            <Ico n="close" size={14}/>
          </button>
        )}
        {onAdd && (
          <button className="adw-icon-btn" style={{ width: 30, height: 30, color: 'var(--accent-color)' }} title="Create" onClick={onAdd}>
            <Ico n="add" size={18}/>
          </button>
        )}
      </div>

      <div className="adw-list-scroll" style={{ gap: tab === 'containers' ? 6 : 4 }}>
        {filtered.length === 0 && search ? (
          <div className="adw-status-page" style={{ padding: '32px 16px', flex: 1 }}>
            <div className="adw-status-page__icon" style={{ width: 48, height: 48, marginBottom: 16 }}><Ico n="search" size={48}/></div>
            <h2 className="adw-status-page__title" style={{ fontSize: '1.125rem' }}>No results</h2>
            <p className="adw-status-page__desc">No {tab} matching "{search}"</p>
          </div>
        ) : content}
      </div>
    </div>
  );
};

// ─── Runtime switcher ─────────────────────────────────────────────────────────
const RuntimeSwitcher = ({ value, onChange }) => {
  const runtimes = ['docker', 'podman', 'containerd'];
  return (
    <div style={{ display: 'flex', background: 'rgba(128,128,128,0.15)', borderRadius: 6, padding: 2, gap: 1 }}>
      {runtimes.map(r => (
        <button key={r} onClick={() => onChange(r)} style={{
          padding: '3px 9px', borderRadius: 4, border: 'none', cursor: 'pointer',
          fontFamily: 'var(--font)', fontSize: '0.8125rem', fontWeight: value === r ? 700 : 400,
          background: value === r ? 'var(--card-bg-color)' : 'transparent',
          color: value === r ? 'var(--headerbar-fg-color)' : 'var(--headerbar-fg-color)',
          opacity: value === r ? 1 : 0.55,
          boxShadow: value === r ? 'var(--shadow-elevated-1)' : 'none',
          transition: 'all 0.12s',
        }}>
          {r}
        </button>
      ))}
    </div>
  );
};

// ─── Main App ─────────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "viewport": "desktop",
  "runtime": "docker"
}/*EDITMODE-END*/;

function App() {
  const { useState, useEffect, useRef } = React;
  const [tweaks, setTweaksState] = useState(TWEAK_DEFAULTS);
  const setTweak = (k, v) => {
    const next = typeof k === 'object' ? { ...tweaks, ...k } : { ...tweaks, [k]: v };
    setTweaksState(next);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: next }, '*');
  };

  const [tab,         setTab]         = useState('home');
  const [containers,  setContainers]  = useState(CONTAINERS);
  const [images,      setImages]      = useState(IMAGES);
  const [volumes,     setVolumes]     = useState(VOLUMES);
  const [networks,    setNetworks]    = useState(NETWORKS);
  const [selected,    setSelected]    = useState(null);
  const [dialog,      setDialog]      = useState(null);
  const [toast,       setToast]       = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [tweaksOpen,  setTweaksOpen]  = useState(false);
  const [mobileView,  setMobileView]  = useState('list');
  const [menuOpen,    setMenuOpen]    = useState(false);
  const [aboutOpen,   setAboutOpen]   = useState(false);
  const [prefsOpen,   setPrefsOpen]   = useState(false);
  const [pullOpen,    setPullOpen]    = useState(false);
  const [createOpen,  setCreateOpen]  = useState(null);
  const [detailScrolled, setDetailScrolled] = useState(false);
  const detailScrollRef = useRef(null);

  // On real mobile devices (Phosh ≤ 600px) always use mobile layout
  const [isRealMobile, setIsRealMobile] = React.useState(() => window.innerWidth <= 600);
  React.useEffect(() => {
    const mq = window.matchMedia('(max-width: 600px)');
    const handler = e => setIsRealMobile(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);
  const isMobile = isRealMobile || tweaks.viewport === 'mobile';
  const isDark   = tweaks.theme === 'dark';

  useEffect(() => {
    const h = e => {
      if (e.data?.type === '__activate_edit_mode')   setTweaksOpen(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', h);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', h);
  }, []);

  const showToast = msg => { setToast(null); setTimeout(() => setToast(msg), 10); };

  const handleContainerAction = (action, c) => {
    if (action === 'remove') { setDialog({ type: 'remove-container', item: c }); return; }
    const next = { stop: 'stopped', start: 'running', pause: 'paused', unpause: 'running', restart: 'running' }[action];
    if (next) {
      setContainers(cs => cs.map(x => x.id !== c.id ? x : { ...x, status: next }));
      if (selected?.id === c.id) setSelected(s => ({ ...s, status: next }));
    }
    const msgs = { stop: 'Container stopped', start: 'Container started', pause: 'Container paused', unpause: 'Container unpaused', restart: 'Container restarted' };
    showToast(msgs[action] || 'Done');
  };

  const handleGenericAction = (action, item, setter, key) => {
    if (action === 'remove') { setDialog({ type: `remove-${key}`, item }); return; }
  };

  const confirmRemove = () => {
    const { type, item } = dialog;
    if (type === 'prune') {
      setContainers(cs => cs.filter(c => c.status === 'running'));
      setImages(is => is.filter(i => i.inUse));
      if (!containers.find(c => c.id === selected?.id && c.status === 'running')) setSelected(null);
      setDialog(null); showToast('System pruned'); return;
    }
    if (type === 'remove-container') { setContainers(cs => cs.filter(x => x.id !== item.id));     if (selected?.id === item.id)   setSelected(null); }
    if (type === 'remove-image')     { setImages(is => is.filter(x => x.id !== item.id));          if (selected?.id === item.id)   setSelected(null); }
    if (type === 'remove-volume')    { setVolumes(vs => vs.filter(x => x.name !== item.name));     if (selected?.name === item.name) setSelected(null); }
    if (type === 'remove-network')   { setNetworks(ns => ns.filter(x => x.id !== item.id));        if (selected?.id === item.id)   setSelected(null); }
    setDialog(null); showToast('Removed');
  };

  const changeTab = t => { setTab(t); setSelected(null); if (isMobile) setMobileView('list'); };
  const handleSelect = item => { setSelected(item); if (isMobile) setMobileView('detail'); };

  const TABS = [
    { id: 'home',       label: 'Home',       icon: 'home'      },
    { id: 'containers', label: 'Containers', icon: 'container' },
    { id: 'images',     label: 'Images',     icon: 'img'       },
    { id: 'volumes',    label: 'Volumes',    icon: 'vol'       },
    { id: 'networks',   label: 'Networks',   icon: 'net'       },
  ];

  const tabItems = tab === 'containers' ? containers : tab === 'images' ? images : tab === 'volumes' ? volumes : tab === 'networks' ? networks : [];
  const detailTitle = selected ? (selected.name || selected.id) : null;

  const addBtn = tab === 'images' ? () => setPullOpen(true)
    : tab === 'volumes'    ? () => setCreateOpen('volume')
    : tab === 'networks'   ? () => setCreateOpen('network')
    : tab === 'containers' ? () => setCreateOpen('container')
    : null;

  return (
    <div data-theme={isDark ? 'dark' : 'light'}>
      <div className={`adw-window ${tweaks.viewport}`}>

        {/* ── AdwHeaderBar ── */}
        <header className="adw-headerbar" role="banner">
          {/* Start slot */}
          <div className="adw-headerbar__start">
            {isMobile && mobileView === 'detail' ? (
              <button className="adw-icon-btn" aria-label="Back" onClick={() => setMobileView('list')}>
                <Ico n="back" size={18}/>
              </button>
            ) : (
              <>
                {!isMobile && (
                  <div className="adw-wm-controls">
                    <div className="adw-wm-btn close" role="button" aria-label="Close"/>
                    <div className="adw-wm-btn min"   role="button" aria-label="Minimize"/>
                    <div className="adw-wm-btn max"   role="button" aria-label="Maximize"/>
                  </div>
                )}
                <div style={{ position: 'relative' }}>
                  <button className="adw-icon-btn" aria-label="Main menu" aria-haspopup="menu" aria-expanded={menuOpen}
                    onClick={e => { e.stopPropagation(); setMenuOpen(o => !o); }}>
                    <Ico n="menu" size={18}/>
                  </button>
                  {menuOpen && (
                    <MenuPopover
                      onClose={() => setMenuOpen(false)}
                      onAbout={() => setAboutOpen(true)}
                      onPrune={() => setDialog({ type: 'prune', item: { name: 'all unused resources' } })}
                      onSettings={() => setPrefsOpen(true)}
                    />
                  )}
                </div>
              </>
            )}
          </div>

          {/* Center slot — ViewSwitcher on desktop, title on mobile */}
          <div className="adw-headerbar__center">
            {isMobile ? (
              <div className="adw-window-title">
                <span className="adw-window-title__title">
                  {mobileView === 'detail' && detailTitle ? detailTitle : 'Doca'}
                </span>
                {(mobileView === 'list' || tab === 'home') && tweaks.runtime && (
                  <span className="adw-window-title__subtitle">{tweaks.runtime}</span>
                )}
              </div>
            ) : (
              <nav className="adw-view-switcher" role="tablist" aria-label="Main navigation">
                {TABS.map(t => (
                  <button key={t.id} role="tab" aria-selected={tab === t.id}
                    className="adw-view-switcher__btn"
                    onClick={() => changeTab(t.id)}>
                    {t.label}
                  </button>
                ))}
              </nav>
            )}
          </div>

          {/* End slot */}
          <div className="adw-headerbar__end">
            {!isMobile && <RuntimeSwitcher value={tweaks.runtime} onChange={v => setTweak('runtime', v)}/>}
            {loading
              ? <Spinner size={18}/>
              : <button className="adw-icon-btn" aria-label="Refresh" onClick={() => { setLoading(true); setTimeout(() => { setLoading(false); showToast('Refreshed'); }, 1200); }}>
                  <Ico n="refresh" size={18}/>
                </button>
            }
            <button className="adw-icon-btn" aria-label="More options"><Ico n="more" size={18}/></button>
          </div>
        </header>

        {/* ── Body ── */}
        <div className="adw-split">
          {/* Sidebar — hidden on Home tab; on mobile shows only when viewing list */}
          {tab !== 'home' && (
            <aside className={`adw-sidebar${isMobile && mobileView === 'list' ? ' mobile-visible' : ''}`}>
              <Sidebar
                tab={tab} items={tabItems} selected={selected}
                onSelect={handleSelect}
                onAction={(a, i) => {
                  if (tab === 'containers') return handleContainerAction(a, i);
                  if (tab === 'images')     return handleGenericAction(a, i, setImages,   'image');
                  if (tab === 'volumes')    return handleGenericAction(a, i, setVolumes,  'volume');
                  if (tab === 'networks')   return handleGenericAction(a, i, setNetworks, 'network');
                }}
                onAdd={addBtn}
              />
            </aside>
          )}

          {/* Detail / Home
              On mobile:
                - home tab  → always visible (mobile-home)
                - other tabs → visible only when mobileView === 'detail'
          */}
          <main
            className={`adw-detail${
              tab === 'home'
                ? ' mobile-home'
                : isMobile && mobileView === 'detail' ? ' mobile-visible' : ''
            }`}
            style={tab === 'home' ? { flex: 1 } : {}}
            role="main"
          >
            {tab === 'home' ? (
              <Dashboard containers={containers} images={images} volumes={volumes} networks={networks} onNavigate={changeTab}/>
            ) : !selected ? (
              <EmptySelection/>
            ) : tab === 'containers' ? (
              <ContainerDetail c={selected} onAction={handleContainerAction}/>
            ) : tab === 'images' ? (
              <ImageDetail img={selected} onAction={(a, i) => handleGenericAction(a, i, setImages, 'image')}/>
            ) : tab === 'volumes' ? (
              <VolumeDetail vol={selected} onAction={(a, i) => handleGenericAction(a, i, setVolumes, 'volume')}/>
            ) : (
              <NetworkDetail net={selected} onAction={(a, i) => handleGenericAction(a, i, setNetworks, 'network')}/>
            )}
          </main>
        </div>

        {/* Mobile bottom navigation — always visible on mobile, on any tab/view
            (on detail view the back arrow handles return, tabs allow switching) */}
        {isMobile && (tab === 'home' || mobileView === 'list' || mobileView === 'detail') && (
          <nav className="adw-bottom-bar" role="tablist" aria-label="Main navigation">
            {TABS.map(t => (
              <button key={t.id} role="tab" aria-selected={tab === t.id}
                className={`adw-bottom-btn${tab === t.id ? ' active' : ''}`}
                onClick={() => changeTab(t.id)}>
                <Ico n={t.icon} size={22}/>
                <span>{t.label}</span>
              </button>
            ))}
          </nav>
        )}

        {/* ── Overlays ── */}
        {prefsOpen && (
          <PreferencesDialog
            onClose={() => setPrefsOpen(false)}
            tweaks={tweaks}
            setTweak={setTweak}
            onPrune={() => setDialog({ type: 'prune', item: { name: 'all unused resources' } })}
          />
        )}

        {aboutOpen && <AboutDialog onClose={() => setAboutOpen(false)}/>}

        {pullOpen && (
          <PullImageDialog onClose={() => setPullOpen(false)} onDone={name => {
            setImages(is => [...is, { id: 'sha256:new' + Date.now(), name: name.split(':')[0], tag: name.split(':')[1] || 'latest', size: '— MB', created: new Date().toISOString().slice(0, 10), inUse: false }]);
            showToast(`Image "${name}" pulled`);
          }}/>
        )}
        {createOpen === 'container' && (
          <CreateContainerWizard images={images} onClose={() => setCreateOpen(null)} onDone={f => {
            const name = f.name || (f.image.split(':')[0] + '-' + Math.random().toString(36).slice(2, 6));
            setContainers(cs => [{
              id: 'new' + Date.now().toString(36), name, image: f.image, status: 'running',
              ports: f.ports.filter(p => p.host).map(p => `0.0.0.0:${p.host}→${p.container}/tcp`).join(', '),
              command: '', compose: null, created: new Date().toISOString(), restart: f.restart,
              env: f.env.filter(e => e.k).map(e => `${e.k}=${e.v}`),
            }, ...cs]);
            showToast(`Container "${name}" created`);
          }}/>
        )}
        {createOpen === 'volume'  && <CreateVolumeDialog  onClose={() => setCreateOpen(null)} onDone={v => { setVolumes(vs => [v, ...vs]);  showToast(`Volume "${v.name}" created`); }}/>}
        {createOpen === 'network' && <CreateNetworkDialog onClose={() => setCreateOpen(null)} onDone={n => { setNetworks(ns => [n, ...ns]); showToast(`Network "${n.name}" created`); }}/>}

        {dialog && (
          <ConfirmDialog
            title={dialog.type === 'prune' ? 'Prune System?' : `Remove ${dialog.type.replace('remove-', '')}?`}
            desc={dialog.type === 'prune'
              ? 'Remove all stopped containers, dangling images, and unused networks. This action cannot be undone.'
              : `"${dialog.item.name || dialog.item.id}" will be permanently removed. This action cannot be undone.`}
            confirmLabel={dialog.type === 'prune' ? 'Prune' : 'Remove'}
            onConfirm={confirmRemove} onCancel={() => setDialog(null)}
          />
        )}

        {toast && <AdwToast key={toast + Date.now()} message={toast} onDone={() => setToast(null)}/>}
      </div>

      {/* ── Tweaks panel ── */}
      {tweaksOpen && (
        <div className="adw-tweaks">
          <div className="adw-tweaks__head">
            Tweaks
            <button className="adw-icon-btn adw-icon-btn--window" style={{ width: 28, height: 28 }}
              onClick={() => { setTweaksOpen(false); window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*'); }}>
              <Ico n="close" size={14}/>
            </button>
          </div>
          <div className="adw-tweaks__body">
            {[
              ['Theme',    ['light', 'dark'],                    'theme'],
              ['Viewport', ['desktop', 'mobile'],                'viewport'],
              ['Runtime',  ['docker', 'podman', 'containerd'],   'runtime'],
            ].map(([label, opts, key]) => (
              <div key={key} className="adw-tweaks__row">
                <span className="adw-tweaks__label">{label}</span>
                <div className="adw-tweaks__segs">
                  {opts.map(v => (
                    <button key={v} className={`adw-tweaks__seg${tweaks[key] === v ? ' active' : ''}`} onClick={() => setTweak(key, v)}>
                      {v.charAt(0).toUpperCase() + v.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <div className="adw-tweaks__row">
              <span className="adw-tweaks__label">Dialogs</span>
              <div className="adw-tweaks__segs">
                <button className="adw-tweaks__seg" onClick={() => setPullOpen(true)}>Pull image</button>
                <button className="adw-tweaks__seg" onClick={() => setCreateOpen('container')}>New container</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
