// ─── Terminal View ────────────────────────────────────────────────────────────
const TERMINAL_RESPONSES = {
  '': '',
  'ls': 'bin  boot  dev  etc  home  lib  lib64  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var',
  'ls -la': `total 72
drwxr-xr-x   1 root root 4096 Jan 15 09:00 .
drwxr-xr-x   1 root root 4096 Jan 15 09:00 ..
drwxr-xr-x   2 root root 4096 Jan 10 00:00 bin
drwxr-xr-x   2 root root 4096 Jan  1  2024 boot
drwxr-xr-x   5 root root  360 Jan 15 09:00 dev
drwxr-xr-x  44 root root 4096 Jan 15 09:00 etc
drwxr-xr-x   2 root root 4096 Jan  1  2024 home
drwxr-xr-x   8 root root 4096 Jan 10 00:00 lib
drwxr-xr-x   2 root root 4096 Jan 10 00:00 lib64
drwxr-xr-x   2 root root 4096 Jan 10 00:00 tmp
drwxr-xr-x  12 root root 4096 Jan 10 00:00 usr
drwxr-xr-x  13 root root 4096 Jan 15 09:00 var`,
  'pwd': '/',
  'whoami': 'root',
  'hostname': 'a3f9b2c1d4e5',
  'uname -a': 'Linux a3f9b2c1d4e5 6.1.0-17-amd64 #1 SMP PREEMPT_DYNAMIC Debian 6.1.69-1 x86_64 GNU/Linux',
  'id': 'uid=0(root) gid=0(root) groups=0(root)',
  'cat /etc/os-release': `PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
NAME="Debian GNU/Linux"
VERSION_ID="12"
VERSION="12 (bookworm)"
ID=debian
HOME_URL="https://www.debian.org/"`,
  'cat /etc/hosts': `127.0.0.1	localhost
::1	localhost ip6-localhost ip6-loopback
172.18.0.3	a3f9b2c1d4e5`,
  'ps aux': `USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         1  0.0  0.1   4528  1024 ?        Ss   09:00   0:00 nginx: master process
nginx       17  0.0  0.2  5076  2048 ?        S    09:00   0:00 nginx: worker process
nginx       18  0.0  0.2  5076  2048 ?        S    09:00   0:00 nginx: worker process`,
  'env': `PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
HOSTNAME=a3f9b2c1d4e5
NGINX_HOST=example.com
NGINX_PORT=80
TZ=UTC`,
  'df -h': `Filesystem      Size  Used Avail Use% Mounted on
overlay         100G   14G   86G  14% /
tmpfs            64M     0   64M   0% /dev
/dev/sda1       100G   14G   86G  14% /etc/hosts`,
  'free -h': `              total        used        free      shared  buff/cache   available
Mem:           15Gi       2.1Gi        11Gi       124Mi       2.0Gi        12Gi
Swap:         2.0Gi          0B       2.0Gi`,
  'top': `top - 10:24:01 up 3 days,  1:23,  0 users,  load average: 0.08, 0.11, 0.09
Tasks:   3 total,   1 running,   2 sleeping
%Cpu(s):  0.7 us,  0.3 sy,  0.0 ni, 98.9 id
MiB Mem: 15360.0 total, 11264.0 free,  2150.4 used
  PID USER  PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME COMMAND
    1 root  20   0    4528   1024    896 S   0.3   0.0   0:00.12 nginx`,
  'nginx -v': 'nginx version: nginx/1.25.3',
  'nginx -t': 'nginx: the configuration file /etc/nginx/nginx.conf syntax is ok\nnginx: configuration file /etc/nginx/nginx.conf test is successful',
  'exit': '__EXIT__',
};

const TerminalView = ({ c }) => {
  const { useState, useEffect, useRef } = React;
  const [lines, setLines] = useState([
    { type:'system', text:`Connected to ${c.name} (${c.id})` },
    { type:'system', text:'Type a command or "exit" to close.' },
  ]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const [disconnected, setDisconnected] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const prompt = `root@${c.id}:/#`;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [lines]);

  const run = (cmd) => {
    const trimmed = cmd.trim();
    const newLines = [...lines, { type:'input', text: `${prompt} ${trimmed}` }];
    const response = TERMINAL_RESPONSES[trimmed];
    if (response === '__EXIT__') {
      setLines([...newLines, { type:'system', text:'Session closed.' }]);
      setDisconnected(true);
      return;
    }
    if (response !== undefined) {
      if (response) newLines.push({ type:'output', text: response });
    } else {
      newLines.push({ type:'error', text: `bash: ${trimmed}: command not found` });
    }
    setLines(newLines);
    setHistory(h => [trimmed, ...h.filter(x=>x!==trimmed)].slice(0,50));
    setHistIdx(-1);
    setInput('');
  };

  const onKey = (e) => {
    if (e.key === 'Enter') { run(input); }
    else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const idx = Math.min(histIdx+1, history.length-1);
      setHistIdx(idx);
      setInput(history[idx] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const idx = Math.max(histIdx-1, -1);
      setHistIdx(idx);
      setInput(idx === -1 ? '' : history[idx]);
    }
  };

  return (
    <div className="log-wrap" onClick={() => inputRef.current?.focus()}>
      <div className="log-toolbar">
        <span className="log-toolbar-title">{c.name} — /bin/bash</span>
        <button className="log-tb-btn" onClick={()=>setLines([])}>Clear</button>
      </div>
      <div className="log-scroll" ref={scrollRef} style={{cursor:'text'}}>
        {lines.map((l,i) => (
          <div key={i} className="log-line">
            {l.type==='input'  && <span style={{color:'#88c0d0'}}>{l.text}</span>}
            {l.type==='output' && <span style={{color:'rgba(255,255,255,0.82)',whiteSpace:'pre'}}>{l.text}</span>}
            {l.type==='error'  && <span style={{color:'#ff7b7b'}}>{l.text}</span>}
            {l.type==='system' && <span style={{color:'rgba(255,255,255,0.35)',fontStyle:'italic'}}>{l.text}</span>}
          </div>
        ))}
        {!disconnected && (
          <div style={{display:'flex',alignItems:'center',gap:4,marginTop:2}}>
            <span style={{color:'#88c0d0',flexShrink:0}}>{prompt}</span>
            <input
              ref={inputRef}
              value={input}
              onChange={e=>setInput(e.target.value)}
              onKeyDown={onKey}
              autoFocus
              style={{
                background:'transparent',border:'none',outline:'none',color:'rgba(255,255,255,0.87)',
                fontFamily:'monospace',fontSize:'8pt',flex:1,caretColor:'rgba(255,255,255,0.8)',
              }}
              placeholder="Type a command…"
            />
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Stats View ───────────────────────────────────────────────────────────────
function generateStats(len=60) {
  const rand = (min,max) => Math.random()*(max-min)+min;
  return Array.from({length:len}, (_,i) => ({
    cpu: rand(0.5, 12) * (1 + Math.sin(i/8)*0.5),
    mem: rand(40, 80),
    netIn: rand(0, 50),
    netOut: rand(0, 30),
  }));
}

const Sparkline = ({ data, color, height=48, fill=true, label, unit='%', min=0, max=100 }) => {
  const W = 240, H = height;
  const pts = data.map((v,i) => {
    const x = (i/(data.length-1))*W;
    const y = H - ((v-min)/(max-min))*(H-4) - 2;
    return [x,y];
  });
  const d = pts.map((p,i) => `${i===0?'M':'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const fillPath = `${d} L${W},${H} L0,${H} Z`;
  const cur = data[data.length-1];
  return (
    <div style={{background:'var(--card-bg)',border:'1px solid var(--card-border)',borderRadius:10,padding:'12px 14px',minWidth:0}}>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
        <span style={{fontSize:'8.5pt',fontWeight:700,color:'var(--txt2)',textTransform:'uppercase',letterSpacing:'0.06em'}}>{label}</span>
        <span style={{fontSize:'11pt',fontWeight:700,color:'var(--txt)'}}>{cur.toFixed(1)}{unit}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} preserveAspectRatio="none">
        <defs>
          <linearGradient id={`g-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3"/>
            <stop offset="100%" stopColor={color} stopOpacity="0.02"/>
          </linearGradient>
        </defs>
        {fill && <path d={fillPath} fill={`url(#g-${label})`}/>}
        <path d={d} fill="none" stroke={color} strokeWidth="1.5"/>
        <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="3" fill={color}/>
      </svg>
    </div>
  );
};

const StatsView = ({ c }) => {
  const { useState, useEffect } = React;
  const [stats, setStats] = useState(() => generateStats(60));

  useEffect(() => {
    if (c.status !== 'running') return;
    const iv = setInterval(() => {
      setStats(s => {
        const last = s[s.length-1];
        const next = {
          cpu:  Math.max(0.1, Math.min(100, last.cpu  + (Math.random()-0.5)*4)),
          mem:  Math.max(10,  Math.min(95,  last.mem  + (Math.random()-0.45)*1.5)),
          netIn:  Math.max(0, last.netIn  + (Math.random()-0.3)*10),
          netOut: Math.max(0, last.netOut + (Math.random()-0.4)*8),
        };
        return [...s.slice(1), next];
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [c.status, c.id]);

  if (c.status !== 'running') return (
    <div className="detail-scroll" style={{alignItems:'center',justifyContent:'center'}}>
      <div className="status-page">
        <div className="status-icon"><Ico n="chart" size={48}/></div>
        <div className="status-title">Not Running</div>
        <div className="status-desc">Stats are only available for running containers.</div>
      </div>
    </div>
  );

  const cur = stats[stats.length-1];
  return (
    <div className="detail-scroll" style={{gap:10}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
        <Sparkline data={stats.map(s=>s.cpu)}    color="#3584e4" label="CPU"     unit="%" max={100} min={0}/>
        <Sparkline data={stats.map(s=>s.mem)}    color="#26a269" label="Memory"  unit="%" max={100} min={0}/>
        <Sparkline data={stats.map(s=>s.netIn)}  color="#f8e45c" label="Net In"  unit=" KB/s" max={100} min={0}/>
        <Sparkline data={stats.map(s=>s.netOut)} color="#e5a50a" label="Net Out" unit=" KB/s" max={100} min={0}/>
      </div>
      <div className="pref-group">
        <div className="pref-group-title">Current</div>
        <div className="pref-rows">
          <PR k="CPU Usage"    v={`${cur.cpu.toFixed(2)}% of 4 cores`}/>
          <PR k="Memory"       v={`${(cur.mem*0.256).toFixed(0)} MB / 256 MB (${cur.mem.toFixed(1)}%)`}/>
          <PR k="Block I/O"    v="12.4 MB / 3.2 MB"/>
          <PR k="Network I/O"  v={`↓ ${cur.netIn.toFixed(1)} KB/s  ↑ ${cur.netOut.toFixed(1)} KB/s`}/>
          <PR k="PIDs"         v="3"/>
        </div>
      </div>
    </div>
  );
};

// ─── Inspect View ─────────────────────────────────────────────────────────────
const InspectView = ({ item }) => {
  const { useState } = React;
  const [copied, setCopied] = useState(false);
  const json = INSPECT_JSON(item);

  const colorize = (json) => {
    return json
      .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(?:\s*:)?)/g, (m) => {
        if (/:$/.test(m)) return `<span style="color:#88c0d0">${m}</span>`;
        return `<span style="color:#a3be8c">${m}</span>`;
      })
      .replace(/\b(true|false)\b/g, '<span style="color:#d08770">$1</span>')
      .replace(/\b(null)\b/g, '<span style="color:#bf616a">$1</span>')
      .replace(/\b(-?\d+\.?\d*)\b/g, '<span style="color:#b48ead">$1</span>');
  };

  const copy = () => {
    navigator.clipboard?.writeText(json).catch(()=>{});
    setCopied(true);
    setTimeout(()=>setCopied(false), 2000);
  };

  return (
    <div className="log-wrap">
      <div className="log-toolbar">
        <span className="log-toolbar-title">docker inspect {item.name || item.id}</span>
        <button className="log-tb-btn" onClick={copy}>
          <Ico n={copied?'check':'copy'} size={12}/> {copied ? 'Copied!' : 'Copy JSON'}
        </button>
      </div>
      <div className="log-scroll" style={{padding:'14px 16px'}}>
        <pre style={{fontSize:'7.5pt',lineHeight:1.7,color:'rgba(255,255,255,0.75)',whiteSpace:'pre-wrap',wordBreak:'break-all'}}
          dangerouslySetInnerHTML={{__html: colorize(json)}}/>
      </div>
    </div>
  );
};

// ─── Image Layers View ────────────────────────────────────────────────────────
const LayersView = ({ img }) => {
  const layers = IMAGE_LAYERS[img.id] || [
    { id:'sha256:'+img.id.slice(7,13), cmd:'FROM scratch', size:'0 B' },
    { id:'sha256:a1b2c3', cmd:'ADD rootfs.tar.gz /', size: img.size },
    { id:'sha256:d4e5f6', cmd:'CMD ["/bin/sh"]', size:'0 B' },
  ];
  let cumulative = 0;
  const parsed = layers.map(l => {
    const mb = parseFloat(l.size) || 0;
    cumulative += mb;
    return { ...l, mb, cumulative };
  });
  const total = cumulative || 1;

  return (
    <div className="detail-scroll">
      <div className="pref-group">
        <div className="pref-group-title">Image Layers — {layers.length} layers · {img.size}</div>
        <div className="pref-rows" style={{gap:0}}>
          {parsed.map((l,i) => (
            <div key={i} className="pref-row" style={{flexDirection:'column',alignItems:'stretch',gap:6,padding:'12px 14px'}}>
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <span style={{width:20,height:20,borderRadius:4,background:'var(--btn-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'7pt',fontWeight:700,color:'var(--txt2)',flexShrink:0}}>{i+1}</span>
                <code style={{fontSize:'8pt',color:'var(--txt)',flex:1,wordBreak:'break-all'}}>{l.cmd}</code>
                <span style={{fontSize:'8pt',color:'var(--txt2)',flexShrink:0}}>{l.size}</span>
              </div>
              {l.mb > 0 && (
                <div style={{height:3,borderRadius:2,background:'var(--sep)',overflow:'hidden',marginLeft:28}}>
                  <div style={{height:'100%',width:`${(l.mb/total)*100}%`,background:'var(--accent)',borderRadius:2}}/>
                </div>
              )}
              <div style={{marginLeft:28,fontSize:'7.5pt',color:'var(--txt2)',fontFamily:'monospace'}}>{l.id}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Detail Panes ─────────────────────────────────────────────────────────────
const CONTAINER_TABS = ['info','logs','stats','terminal','inspect'];
const TAB_LABELS = { info:'Info', logs:'Logs', stats:'Stats', terminal:'Terminal', inspect:'Inspect' };

const ContainerDetail = ({ c, onAction, logsData }) => {
  const { useState, useEffect, useRef } = React;
  const [dtab, setDtab] = useState('info');
  useEffect(() => setDtab('info'), [c.id]);

  const ts = (h,m,s) => `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  const mockLogs = {
    'a3f9b2c1': [{t:ts(10,12,3),l:'info',m:'nginx/1.25.3 starting'},{t:ts(10,14,22),l:'info',m:'10.0.0.1 - GET / 200'},{t:ts(10,15,7),l:'warn',m:'upstream slow: 2.3s'},{t:ts(10,22,1),l:'info',m:'10.0.0.1 - GET /api 200'}],
    'b7c3e8f2': [{t:ts(9,55,1),l:'info',m:'PostgreSQL 15.4 starting'},{t:ts(9,55,3),l:'info',m:'Ready to accept connections'},{t:ts(10,11,30),l:'warn',m:'connection pool: 95/100 used'},{t:ts(10,11,31),l:'error',m:'auth failed from 172.18.0.5'}],
    'e5f9d2a4': [{t:ts(11,0,0),l:'info',m:'Grafana v10.2.3'},{t:ts(11,0,1),l:'info',m:'HTTP Server on :3000'},{t:ts(11,0,2),l:'info',m:'Database connected'}],
    'f1b7c3e9': [{t:ts(10,0,0),l:'info',m:'Prometheus 2.x starting'},{t:ts(10,0,1),l:'info',m:'Listening on :9090'}],
  };
  const logLines = mockLogs[c.id] || [{t:ts(10,0,0),l:'info',m:'Container started'}];

  const LogsView = () => {
    const [lines, setLines] = useState(logLines.map((l,i)=>({...l,id:i})));
    const [follow, setFollow] = useState(c.status==='running');
    const scrollRef = useRef(null);
    const counter = useRef(lines.length);
    const pool = [{l:'info',m:'GET /health 200 2ms'},{l:'info',m:'GET /api/data 200 18ms'},{l:'warn',m:'slow response: 320ms'}];
    useEffect(()=>{ if(scrollRef.current) scrollRef.current.scrollTop=scrollRef.current.scrollHeight; },[lines]);
    useEffect(()=>{ if(scrollRef.current) scrollRef.current.scrollTop=scrollRef.current.scrollHeight; },[]);
    useEffect(()=>{
      if(c.status!=='running'||!follow) return;
      let i=0; const iv=setInterval(()=>{
        const src=pool[i++%pool.length];
        setLines(ls=>[...ls,{...src,t:now(),id:counter.current++}]);
      },2200);
      return ()=>clearInterval(iv);
    },[c.status,follow]);
    return (
      <div className="log-wrap">
        <div className="log-toolbar">
          <span className="log-toolbar-title">{c.name} · stdout+stderr</span>
          {c.status==='running'&&<button className={`log-tb-btn${follow?' active':''}`} onClick={()=>setFollow(f=>!f)}><Ico n="download" size={12}/> {follow?'Following':'Follow'}</button>}
          <button className="log-tb-btn" onClick={()=>setLines([])}><Ico n="trash" size={12}/> Clear</button>
        </div>
        <div className="log-scroll" ref={scrollRef}>
          {lines.map(line=>(
            <div key={line.id} className="log-line">
              <span className="log-ts">{line.t}</span>
              <span className={`log-lvl ${line.l}`}>{line.l.toUpperCase()}</span>
              <span className={`log-msg${line.l==='error'?' err':''}`}>{line.m}</span>
            </div>
          ))}
          {follow&&c.status==='running'&&<span className="log-cursor"/>}
        </div>
      </div>
    );
  };

  return (
    <div style={{display:'flex',flexDirection:'column',flex:1,overflow:'hidden'}}>
      <div style={{display:'flex',alignItems:'center',gap:6,padding:'6px 14px',borderBottom:'1px solid var(--sep)',background:'var(--detail-bg)',flexShrink:0,flexWrap:'wrap'}}>
        <StatusBadge status={c.status}/>
        <span style={{fontWeight:700,color:'var(--txt)',fontSize:'10pt'}}>{c.name}</span>
        <div style={{flex:1}}/>
        <div className="detail-tabs">
          {CONTAINER_TABS.map(t=>(
            <button key={t} className={`dtab${dtab===t?' active':''}`} onClick={()=>setDtab(t)}>
              {TAB_LABELS[t]}
            </button>
          ))}
        </div>
      </div>
      {dtab==='info' && (
        <div className="detail-scroll">
          <div className="detail-actions">
            {(c.status==='running'||c.status==='paused')&&<PillBtn variant="destructive" onClick={()=>onAction('stop',c)}><Ico n="stop" size={14}/> Stop</PillBtn>}
            {(c.status==='stopped'||c.status==='exited'||c.status==='error')&&<PillBtn variant="primary" onClick={()=>onAction('start',c)}><Ico n="play" size={14}/> Start</PillBtn>}
            {c.status==='running'&&<PillBtn variant="neutral" onClick={()=>onAction('pause',c)}><Ico n="pause" size={14}/> Pause</PillBtn>}
            {c.status==='paused'&&<PillBtn variant="neutral" onClick={()=>onAction('unpause',c)}><Ico n="play" size={14}/> Unpause</PillBtn>}
            <PillBtn variant="neutral" onClick={()=>onAction('restart',c)}><Ico n="restart" size={14}/> Restart</PillBtn>
            <PillBtn variant="destructive" style={{marginLeft:'auto'}} onClick={()=>onAction('remove',c)}><Ico n="trash" size={14}/> Remove…</PillBtn>
          </div>
          <div className="pref-group">
            <div className="pref-group-title">Properties</div>
            <div className="pref-rows">
              <PR k="Name"    v={c.name}/>
              <PR k="ID"      v={c.id} mono/>
              <PR k="Image"   v={c.image}/>
              <PR k="Command" v={c.command} mono/>
              <PR k="Status"  v={<StatusBadge status={c.status}/>}/>
              <PR k="Ports"   v={c.ports||'—'}/>
              <PR k="Restart" v={c.restart}/>
              {c.compose && <PR k="Compose" v={c.compose}/>}
            </div>
          </div>
          {c.env && c.env.length > 0 && (
            <div className="pref-group">
              <div className="pref-group-title">Environment</div>
              <div className="pref-rows">
                {c.env.map((e,i)=>{
                  const [k,...rest]=e.split('='); const v=rest.join('=');
                  const isSecret = /pass|secret|key|token/i.test(k);
                  return <PR key={i} k={k} v={isSecret ? '••••••••' : v} mono/>;
                })}
              </div>
            </div>
          )}
        </div>
      )}
      {dtab==='logs'     && <LogsView key={c.id}/>}
      {dtab==='stats'    && <StatsView c={c}/>}
      {dtab==='terminal' && (c.status==='running'
        ? <TerminalView key={c.id} c={c}/>
        : <div className="status-page"><div className="status-icon"><Ico n="terminal" size={48}/></div><div className="status-title">Not Running</div><div className="status-desc">Start the container to open a terminal.</div></div>
      )}
      {dtab==='inspect'  && <InspectView item={c}/>}
    </div>
  );
};

const ImageDetail = ({ img, onAction }) => {
  const { useState } = React;
  const [tab, setTab] = useState('info');
  return (
    <div style={{display:'flex',flexDirection:'column',flex:1,overflow:'hidden'}}>
      <div style={{display:'flex',alignItems:'center',gap:6,padding:'6px 14px',borderBottom:'1px solid var(--sep)',background:'var(--detail-bg)',flexShrink:0}}>
        <span style={{fontWeight:700,color:'var(--txt)',fontSize:'10pt'}}>{img.name}:{img.tag}</span>
        <div style={{flex:1}}/>
        <div className="detail-tabs">
          {['info','layers'].map(t=><button key={t} className={`dtab${tab===t?' active':''}`} onClick={()=>setTab(t)}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>)}
        </div>
      </div>
      {tab==='info' && (
        <div className="detail-scroll">
          <div className="detail-actions">
            <PillBtn variant="neutral"><Ico n="play" size={14}/> Run…</PillBtn>
            <PillBtn variant="neutral"><Ico n="download" size={14}/> Push…</PillBtn>
            <PillBtn variant="destructive" style={{marginLeft:'auto'}} onClick={()=>onAction('remove',img)}><Ico n="trash" size={14}/> Remove…</PillBtn>
          </div>
          <div className="pref-group">
            <div className="pref-group-title">Properties</div>
            <div className="pref-rows">
              <PR k="Name"    v={img.name}/>
              <PR k="Tag"     v={img.tag}/>
              <PR k="ID"      v={img.id} mono/>
              <PR k="Size"    v={img.size}/>
              <PR k="Created" v={img.created}/>
              <PR k="In Use"  v={img.inUse ? '✓ Yes' : '✗ No — can be pruned'}/>
            </div>
          </div>
        </div>
      )}
      {tab==='layers' && <LayersView img={img}/>}
    </div>
  );
};

const VolumeDetail = ({ vol, onAction }) => (
  <div className="detail-scroll">
    <div className="detail-actions">
      <PillBtn variant="destructive" onClick={()=>onAction('remove',vol)}><Ico n="trash" size={14}/> Remove…</PillBtn>
    </div>
    <div className="pref-group">
      <div className="pref-group-title">Properties</div>
      <div className="pref-rows">
        <PR k="Name"       v={vol.name}/>
        <PR k="Driver"     v={vol.driver}/>
        <PR k="Mountpoint" v={vol.mountpoint} mono/>
        <PR k="Size"       v={vol.size}/>
        <PR k="In Use"     v={vol.inUse ? '✓ Yes' : '✗ No — can be pruned'}/>
      </div>
    </div>
  </div>
);

const NetworkDetail = ({ net, onAction }) => (
  <div className="detail-scroll">
    <div className="detail-actions">
      {net.name!=='bridge'&&net.name!=='host'&&net.name!=='none'&&
        <PillBtn variant="destructive" onClick={()=>onAction('remove',net)}><Ico n="trash" size={14}/> Remove…</PillBtn>}
    </div>
    <div className="pref-group">
      <div className="pref-group-title">Properties</div>
      <div className="pref-rows">
        <PR k="Name"      v={net.name}/>
        <PR k="ID"        v={net.id} mono/>
        <PR k="Driver"    v={net.driver}/>
        <PR k="Subnet"    v={net.subnet}/>
        <PR k="Gateway"   v={net.gateway}/>
        <PR k="Internal"  v={net.internal ? 'Yes' : 'No'}/>
        <PR k="Containers" v={`${net.containers} connected`}/>
      </div>
    </div>
  </div>
);

const EmptySelection = () => (
  <div className="status-page">
    <div className="status-icon">
      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="var(--txt)" strokeWidth="1.2" opacity="0.3" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2"/>
        <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/>
        <line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/>
      </svg>
    </div>
    <div className="status-title">No Selection</div>
    <div className="status-desc">Select an item from the list to view its details.</div>
  </div>
);

const EmptyList = ({ tab }) => {
  const msgs = {
    containers:{ icon:'container', title:'No Containers',  desc:'No containers found. Run a container to get started.' },
    images:    { icon:'img',       title:'No Images',      desc:'No images found. Pull an image to get started.' },
    volumes:   { icon:'vol',       title:'No Volumes',     desc:'No volumes found. Create a volume to get started.' },
    networks:  { icon:'net',       title:'No Networks',    desc:'No networks configured.' },
  };
  const m = msgs[tab] || msgs.containers;
  return (
    <div className="status-page">
      <div className="status-icon" style={{opacity:0.3}}><Ico n={m.icon} size={56}/></div>
      <div className="status-title">{m.title}</div>
      <div className="status-desc">{m.desc}</div>
    </div>
  );
};

Object.assign(window, {
  TerminalView, StatsView, InspectView, LayersView,
  ContainerDetail, ImageDetail, VolumeDetail, NetworkDetail,
  EmptySelection, EmptyList,
});
