# Prompt de Refatoração — Doca v3

## Contexto

Você está trabalhando em um protótipo de aplicação desktop-style chamado **Doca**, construído em React (JSX via Babel, sem bundler). A aplicação simula uma GUI no estilo GNOME/libadwaita para gerenciar containers Docker/Podman/containerd.

A estrutura atual de arquivos é:

```
Doca.html              ← entrada principal
doca-core.jsx          ← ícones, dados mock, componentes atômicos (Ico, StatusBadge, PR, Spinner…)
doca-features.jsx      ← views de detalhe (ContainerDetail, ImageDetail, VolumeDetail, NetworkDetail, EmptyStates)
doca-dialogs.jsx       ← diálogos modais (Confirm, PullImage, CreateContainer, CreateVolume, CreateNetwork, Menu, About)
doca-app.jsx           ← Dashboard, Sidebar, rows de lista, RuntimeSwitcher, App root, Tweaks panel
```

Os arquivos compartilham escopo via `Object.assign(window, {...})` ao final de cada JSX, pois cada `<script type="text/babel">` tem escopo isolado.

---

## Bugs a corrigir

### Bug 1 — Desalinhamento no Dashboard (aba Home): `Host Resources` vs `Recent Events`

**Arquivo:** `doca-app.jsx` → componente `Dashboard`

**Causa raiz:** Os dois cards estão num grid `1fr 1fr`, mas possuem alturas internas diferentes:
- `Host Resources` usa `adw-pref-row` com `flexDirection: column` (mais alto por item)
- `Recent Events` usa `adw-pref-row` com `minHeight: unset` e padding reduzido

O resultado é que os dois `adw-prefs-group__listbox` ficam com alturas diferentes e o grid fica desalinhado visualmente porque os headers (`adw-prefs-group__header`) têm alturas inconsistentes também.

**Correção esperada:**
- Envolver cada bloco em um `div` com `display: flex; flex-direction: column` para que o `adw-prefs-group__listbox` preencha o espaço restante com `flex: 1`
- Garantir que os dois cards do grid tenham `align-items: stretch` (já está no grid, mas os filhos precisam participar do stretch)
- Adicionar `height: 100%` ou `flex: 1` no `adw-prefs-group__listbox` dos dois blocos para que se igualem

Trecho relevante a modificar (dentro do `<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>` do Dashboard):

```jsx
// ANTES — os dois blocos são divs simples que não participam do stretch
<div className="adw-prefs-group"> ... </div>
<div className="adw-prefs-group"> ... </div>

// DEPOIS — cada bloco deve ser flex-column e o listbox deve crescer
<div className="adw-prefs-group" style={{ display: 'flex', flexDirection: 'column' }}>
  <div className="adw-prefs-group__header">...</div>
  <div className="adw-prefs-group__listbox" style={{ flex: 1 }}>...</div>
</div>
```

---

### Bug 2 — Badge de status sobrepondo título/subtítulo na listagem de containers

**Arquivo:** `doca-app.jsx` → componente `ContainerRow`

**Causa raiz:** O `StatusBadge` está no `adw-action-row__prefix` (largura fixa `32px`), mas o badge tem `white-space: nowrap` e pode ter largura variável ("Running", "Restarting", etc.). Quando o badge é mais largo que 32px, ele vaza para cima do `adw-action-row__body` porque o prefix tem `width: 32px; height: 32px` sem `overflow: hidden`.

Além disso, o CSS de `.adw-action-row__prefix` define `width: 32px` que é insuficiente para um badge. O badge não é um ícone — não deveria estar no `__prefix`.

**Correção esperada:**
- Mover o `StatusBadge` para o `adw-action-row__suffix` (lado direito), antes dos botões de ação — este é o padrão correto para badges em action rows do estilo libadwaita
- **OU** criar um slot intermediário dedicado entre `__body` e `__suffix` com `flex-shrink: 0` e largura automática
- O `__prefix` deve conter apenas ícones de tamanho fixo

```jsx
// ANTES
const ContainerRow = ({ c, ... }) => (
  <div className="adw-action-row ...">
    <div className="adw-action-row__prefix">
      <StatusBadge status={c.status}/>   {/* ← badge no prefix de 32px → vaza */}
    </div>
    <div className="adw-action-row__body">...</div>
    <div className="adw-action-row__suffix">
      {/* botões */}
    </div>
  </div>
);

// DEPOIS — badge vai para o suffix, prefix recebe um ícone de container
const ContainerRow = ({ c, ... }) => (
  <div className="adw-action-row ...">
    <div className="adw-action-row__prefix">
      <Ico n="container" size={20}/>    {/* ícone fixo no prefix */}
    </div>
    <div className="adw-action-row__body">
      <span className="adw-action-row__title">{c.name}</span>
      <span className="adw-action-row__subtitle">{c.image}</span>
    </div>
    <div className="adw-action-row__suffix" onClick={e => e.stopPropagation()}>
      <StatusBadge status={c.status}/>  {/* ← badge no suffix, com espaço adequado */}
      {/* botões de ação */}
    </div>
  </div>
);
```

---

### Bug 3 — Botão "Preferences" no menu não tem ação

**Arquivo:** `doca-dialogs.jsx` → componente `MenuPopover`  
**Arquivo:** `doca-app.jsx` → onde `MenuPopover` é instanciado

**Causa raiz:** O botão "Preferences" no `MenuPopover` chama `onSettings && onSettings()`, mas na chamada em `cm3-app.jsx` a prop `onSettings` nunca é passada:

```jsx
// doca-app.jsx — MenuPopover instanciado sem onSettings
<MenuPopover
  onClose={() => setMenuOpen(false)}
  onAbout={() => setAboutOpen(true)}
  onPrune={() => setDialog({ type: 'prune', item: { name: 'all unused resources' } })}
  // ← onSettings está faltando!
/>
```

**Correção esperada:** Criar uma view/dialog de `Preferences` e conectá-la ao fluxo.

**O que a view de Preferences deve conter** (baseado no padrão libadwaita `AdwPreferencesWindow`):

```
┌─ Preferences ──────────────────────────────────┐
│                                                  │
│  GENERAL                                         │
│  ┌──────────────────────────────────────────┐    │
│  │ Theme          [System] [Light] [Dark]   │    │
│  │ Runtime        [Docker] [Podman] [containerd]│ │
│  │ Refresh interval    ▼ 30 seconds         │    │
│  └──────────────────────────────────────────┘    │
│                                                  │
│  CONTAINER DEFAULTS                              │
│  ┌──────────────────────────────────────────┐    │
│  │ Restart policy      ▼ unless-stopped     │    │
│  │ Stop timeout        ▼ 10 seconds         │    │
│  └──────────────────────────────────────────┘    │
│                                                  │
│  DANGER ZONE                                     │
│  ┌──────────────────────────────────────────┐    │
│  │ [Prune all unused resources…]            │    │
│  └──────────────────────────────────────────┘    │
│                                                  │
└──────────────────────────────────────────────────┘
```

**Implementação:**

1. Criar componente `PreferencesDialog` em `doca-dialogs.jsx`:
   - Usar `adw-scrim` + `adw-dialog` (maxWidth: 480px)
   - Seções com `adw-prefs-group` + `adw-prefs-group__listbox`
   - Rows com `adw-pref-row` contendo label + controle (select ou segmented control inline)
   - O estado interno pode ser local (não precisa persistir fora do dialog no protótipo)

2. Exportar via `Object.assign(window, { ..., PreferencesDialog })`

3. Em `doca-app.jsx`:
   - Adicionar state: `const [prefsOpen, setPrefsOpen] = useState(false)`
   - Passar `onSettings={() => setPrefsOpen(true)}` para `MenuPopover`
   - Renderizar `{prefsOpen && <PreferencesDialog onClose={() => setPrefsOpen(false)} tweaks={tweaks} setTweak={setTweak}/>}` junto com os outros overlays

---

## Refatoração de componentização (opcional, mas recomendada)

Além dos bugs, avaliar as seguintes melhorias de estrutura:

### 1. Separar dados mock de `doca-core.jsx`
`doca-core.jsx` mistura constantes de dados (`CONTAINERS`, `IMAGES`, `VOLUMES`, `NETWORKS`, `EVENTS`, `IMAGE_LAYERS`, `INSPECT_JSON`) com componentes de UI (`Ico`, `StatusBadge`, `PR`, `Spinner`). Considerar extrair para um `doca-data.jsx` separado.

### 2. Extrair rows da sidebar de `doca-app.jsx`
`ContainerRow`, `ImageRow`, `VolumeRow`, `NetworkRow` e `Sidebar` poderiam ir para `doca-features.jsx` ou um `doca-sidebar.jsx` dedicado, já que `doca-app.jsx` ficaria responsável apenas pela orquestração do `App` raiz.

### 3. Dashboard em arquivo próprio
O componente `Dashboard` em `doca-app.jsx` tem lógica de estado e renderização suficiente para justificar extração — mas priorizar os bugs primeiro.

---

## Ordem de execução recomendada

1. **Corrigir Bug 2** (badge sobrepondo título) — impacto visual imediato, mudança cirúrgica em `ContainerRow`
2. **Corrigir Bug 1** (desalinhamento Home) — ajuste de layout em `Dashboard`
3. **Corrigir Bug 3** (criar `PreferencesDialog` e conectar) — adição de novo componente + wiring

Para cada correção: editar o arquivo correspondente com `str_replace_edit`, mantendo o restante do código intacto.

---

## Constraints importantes

- Não usar `type="module"` nos scripts
- Manter o padrão `Object.assign(window, {...})` ao final de cada JSX para exportar componentes entre arquivos
- Não renomear variáveis de estilo globais — se precisar de um objeto `styles`, usar nome específico (ex: `prefsDialogStyles`) para evitar colisão de escopo
- O CSS global fica em `Doca.html` e não deve ser duplicado nos JSX
- Manter compatibilidade com o sistema de Tweaks existente (painel de tweaks já funciona via `window.parent.postMessage`)
