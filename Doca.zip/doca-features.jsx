// ─── Terminal ─────────────────────────────────────────────────────────────────
// Exec-mode terminal: one command at a time via container exec, output appended.
// Matches the GTK code's batch-exec model (gtk4::TextView + Entry + shell DropDown).
const EXEC_MOCK = {
  'ls':       'bin  boot  dev  etc  home  lib  lib64  usr  var',
  'ls -la':   'total 72\ndrwxr-xr-x 1 root root 4096 Jan 15 09:00 .\ndrwxr-xr-x 1 root root 4096 Jan 15 09:00 ..',
  'pwd':      '/',
  'whoami':   'root',
  'hostname': 'a3f9b2c1d4e5',
  'uname -a': 'Linux a3f9b2c1d4e5 6.1.0-17-amd64 #1 SMP x86_64 GNU/Linux',
  'ps aux':   'USER  PID %CPU %MEM COMMAND\nroot    1  0.0  0.1 nginx: master',
  'env':      'PATH=/usr/local/sbin:/usr/bin:/sbin:/bin\nHOSTNAME=a3f9b2c1d4e5',
};

const TerminalView = ({ c }) => {
  const { useState, useEffect, useRef } = React;
  const [lines, setLines] = useState([]);
  const [input, setInput] = useState('');
  const [shell, setShell] = useState('bash');
  const [history, setHistory] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [lines]);

  const run = (cmd) => {
    const trimmed = cmd.trim();
    if (!trimmed) return;
    if (trimmed === 'exit') {
      setLines([]);
      setHistory(h => [trimmed, ...h.filter(x => x !== trimmed)].slice(0, 50));
      setHistIdx(-1);
      setInput('');
      return;
    }
    const output = EXEC_MOCK[trimmed] !== undefined
      ? EXEC_MOCK[trimmed]
      : `${trimmed}: command not found`;
    setLines(l => [
      ...l,
      { type: 'input',  text: `$ ${trimmed}` },
      ...(output ? [{ type: 'output', text: output }] : []),
    ]);
    setHistory(h => [trimmed, ...h.filter(x => x !== trimmed)].slice(0, 50));
    setHistIdx(-1);
    setInput('');
  };

  const onKey = (e) => {
    if (e.key === 'Enter') run(input);
    else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const idx = Math.min(histIdx + 1, history.length - 1);
      setHistIdx(idx);
      setInput(history[idx] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const idx = Math.max(histIdx - 1, -1);
      setHistIdx(idx);
      setInput(idx === -1 ? '' : history[idx]);
    }
  };

  return (
    <div className="adw-terminal">
      <div className="adw-terminal__toolbar">
        <span className="adw-terminal__title">{c.name} — exec</span>
        <select value={shell} onChange={e => setShell(e.target.value)} style={{
          background: 'transparent', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.18)',
          borderRadius: 4, padding: '1px 6px', fontSize: '0.75rem', cursor: 'pointer',
        }}>
          <option value="bash">bash</option>
          <option value="sh">sh</option>
        </select>
        <button className="adw-terminal__btn" onClick={() => setLines([])}>Clear</button>
      </div>
      <div className="adw-terminal__scroll" ref={scrollRef}>
        {lines.length === 0 && (
          <div className="adw-log-line">
            <span style={{ color: 'rgba(255,255,255,0.35)', fontStyle: 'italic' }}>
              Run a command with {shell}. Type "exit" to clear.
            </span>
          </div>
        )}
        {lines.map((l, i) => (
          <div key={i} className="adw-log-line">
            {l.type === 'input'  && <span style={{ color: '#88c0d0', fontFamily: 'var(--font-mono)' }}>{l.text}</span>}
            {l.type === 'output' && <span style={{ color: 'rgba(255,255,255,0.82)', whiteSpace: 'pre' }}>{l.text}</span>}
          </div>
        ))}
      </div>
      <div style={{
        display: 'flex', gap: 6, padding: '8px 12px',
        borderTop: '1px solid rgba(255,255,255,0.1)', background: 'rgba(0,0,0,0.15)',
      }}>
        <input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKey}
          autoFocus
          placeholder="Enter command…"
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            color: 'rgba(255,255,255,0.87)', fontFamily: 'var(--font-mono)', fontSize: '0.8125rem',
          }}
        />
        <button
          className="adw-terminal__btn"
          onClick={() => run(input)}
          style={{ opacity: input.trim() ? 1 : 0.4 }}
        >Run</button>
      </div>
    </div>
  );
};

// ─── Stats View ───────────────────────────────────────────────────────────────
function generateStats(len = 60) {
  const r = (min, max) => Math.random() * (max - min) + min;
  return Array.from({ length: len }, (_, i) => ({
    cpu:    r(0.5, 12) * (1 + Math.sin(i / 8) * 0.5),
    mem:    r(40, 80),
    netIn:  r(0, 50),
    netOut: r(0, 30),
  }));
}

const Sparkline = ({ data, color, height = 44, label, unit = '%', min = 0, max = 100 }) => {
  const W = 240, H = height;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * W;
    const y = H - ((v - min) / (max - min)) * (H - 4) - 2;
    return [x, y];
  });
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const fillPath = `${d} L${W},${H} L0,${H} Z`;
  const cur = data[data.length - 1];
  return (
    <div className="adw-sparkline-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--window-fg-color)', opacity: 0.55, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</span>
        <span style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--window-fg-color)' }}>{cur.toFixed(1)}{unit}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} preserveAspectRatio="none">
        <defs>
          <linearGradient id={`sg-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3"/>
            <stop offset="100%" stopColor={color} stopOpacity="0.02"/>
          </linearGradient>
        </defs>
        <path d={fillPath} fill={`url(#sg-${label})`}/>
        <path d={d} fill="none" stroke={color} strokeWidth="1.5"/>
        <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3" fill={color}/>
      </svg>
    </div>
  );
};

const StatsView = ({ c }) => {
  const { useState, useEffect } = React;
  const [stats, setStats] = useState(() => generateStats(60));

  useEffect(() => {
    if (c.status !== 'running') return;
    const iv = setInterval(() => {
      setStats(s => {
        const last = s[s.length - 1];
        return [...s.slice(1), {
          cpu:    Math.max(0.1, Math.min(100, last.cpu    + (Math.random() - 0.5) * 4)),
          mem:    Math.max(10,  Math.min(95,  last.mem    + (Math.random() - 0.45) * 1.5)),
          netIn:  Math.max(0,   last.netIn  + (Math.random() - 0.3) * 10),
          netOut: Math.max(0,   last.netOut + (Math.random() - 0.4) * 8),
        }];
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [c.status, c.id]);

  if (c.status !== 'running') return (
    <div className="adw-status-page" style={{ flex: 1 }}>
      <div className="adw-status-page__icon"><Ico n="chart" size={80}/></div>
      <h2 className="adw-status-page__title">Not Running</h2>
      <p className="adw-status-page__desc">Stats are only available for running containers.</p>
    </div>
  );

  const cur = stats[stats.length - 1];
  return (
    <div className="adw-detail-scroll">
      <div className="dash-grid-2" style={{ gap: 10 }}>
        <Sparkline data={stats.map(s => s.cpu)}    color="var(--accent-color)"  label="CPU"     unit="%" />
        <Sparkline data={stats.map(s => s.mem)}    color="var(--success-color)" label="Memory"  unit="%" />
        <Sparkline data={stats.map(s => s.netIn)}  color="var(--warning-color)" label="Net In"  unit=" KB/s" max={100} min={0}/>
        <Sparkline data={stats.map(s => s.netOut)} color="#a29bfe"              label="Net Out" unit=" KB/s" max={100} min={0}/>
      </div>
      <div className="adw-prefs-group">
        <div className="adw-prefs-group__header">
          <h3 className="adw-prefs-group__title">Current Usage</h3>
        </div>
        <div className="adw-prefs-group__listbox">
          <PR k="CPU Usage"   v={`${cur.cpu.toFixed(2)}% of 4 cores`}/>
          <PR k="Memory"      v={`${(cur.mem * 0.256).toFixed(0)} MB / 256 MB (${cur.mem.toFixed(1)}%)`}/>
          <PR k="Network I/O" v={`↓ ${cur.netIn.toFixed(1)} KB/s  ↑ ${cur.netOut.toFixed(1)} KB/s`}/>
          <PR k="Block I/O"   v="12.4 MB / 3.2 MB"/>
          <PR k="PIDs"        v="3"/>
        </div>
      </div>
    </div>
  );
};

// ─── Inspect View ─────────────────────────────────────────────────────────────
const InspectView = ({ item }) => {
  const { useState } = React;
  const [copied, setCopied] = useState(false);
  const json = INSPECT_JSON(item);

  const colorize = (j) => j
    .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(?:\s*:)?)/g, m =>
      /:$/.test(m) ? `<span style="color:#88c0d0">${m}</span>` : `<span style="color:#a3be8c">${m}</span>`)
    .replace(/\b(true|false)\b/g, '<span style="color:#d08770">$1</span>')
    .replace(/\b(null)\b/g, '<span style="color:#bf616a">$1</span>')
    .replace(/\b(-?\d+\.?\d*)\b/g, '<span style="color:#b48ead">$1</span>');

  const copy = () => {
    navigator.clipboard?.writeText(json).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="adw-terminal">
      <div className="adw-terminal__toolbar">
        <span className="adw-terminal__title">docker inspect {item.name || item.id}</span>
        <button className="adw-terminal__btn" onClick={copy}>
          <Ico n={copied ? 'check' : 'copy'} size={12}/> {copied ? 'Copied!' : 'Copy JSON'}
        </button>
      </div>
      <div className="adw-terminal__scroll" style={{ padding: '14px 16px' }}>
        <pre style={{ fontSize: '0.75rem', lineHeight: 1.7, color: 'rgba(255,255,255,0.75)', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}
          dangerouslySetInnerHTML={{ __html: colorize(json) }}/>
      </div>
    </div>
  );
};

// ─── Image Layers View ────────────────────────────────────────────────────────
const LayersView = ({ img }) => {
  const layers = IMAGE_LAYERS[img.id] || [
    { id: 'sha256:' + img.id.slice(7, 13), cmd: 'FROM scratch', size: '0 B' },
    { id: 'sha256:a1b2c3', cmd: 'ADD rootfs.tar.gz /', size: img.size },
    { id: 'sha256:d4e5f6', cmd: 'CMD ["/bin/sh"]', size: '0 B' },
  ];
  let cumulative = 0;
  const parsed = layers.map(l => {
    const mb = parseFloat(l.size) || 0;
    cumulative += mb;
    return { ...l, mb, cumulative };
  });
  const total = cumulative || 1;

  return (
    <div className="adw-detail-scroll">
      <div className="adw-prefs-group">
        <div className="adw-prefs-group__header">
          <h3 className="adw-prefs-group__title">{layers.length} Layers · {img.size}</h3>
        </div>
        <div className="adw-prefs-group__listbox">
          {parsed.map((l, i) => (
            <div key={i} className="adw-pref-row" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 6, padding: '12px 14px' }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ width: 22, height: 22, borderRadius: 4, background: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.6875rem', fontWeight: 700, color: 'var(--window-fg-color)', opacity: 0.55, flexShrink: 0 }}>{i + 1}</span>
                <code style={{ fontSize: '0.8125rem', color: 'var(--card-fg-color)', flex: 1, wordBreak: 'break-all', fontFamily: 'var(--font-mono)' }}>{l.cmd}</code>
                <span style={{ fontSize: '0.8125rem', color: 'var(--card-fg-color)', opacity: 0.55, flexShrink: 0 }}>{l.size}</span>
              </div>
              {l.mb > 0 && (
                <div style={{ height: 3, borderRadius: 2, background: 'var(--border-color)', overflow: 'hidden', marginLeft: 30 }}>
                  <div style={{ height: '100%', width: `${(l.mb / total) * 100}%`, background: 'var(--accent-bg-color)', borderRadius: 2 }}/>
                </div>
              )}
              <div style={{ marginLeft: 30, fontSize: '0.6875rem', color: 'var(--card-fg-color)', opacity: 0.4, fontFamily: 'var(--font-mono)' }}>{l.id}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Container Detail ─────────────────────────────────────────────────────────
const CONTAINER_TABS = ['info', 'logs', 'stats', 'terminal', 'inspect'];
const TAB_LABELS = { info: 'Info', logs: 'Logs', stats: 'Stats', terminal: 'Terminal', inspect: 'Inspect' };

const ContainerDetail = ({ c, onAction }) => {
  const { useState, useEffect, useRef } = React;
  const [dtab, setDtab] = useState('info');
  useEffect(() => setDtab('info'), [c.id]);

  const ts = (h, m, s) => [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
  const mockLogs = {
    'a3f9b2c1': [{ t: ts(10,12,3), l:'info', m:'nginx/1.25.3 starting' }, { t: ts(10,14,22), l:'info', m:'10.0.0.1 - GET / 200' }, { t: ts(10,15,7), l:'warn', m:'upstream slow: 2.3s' }],
    'b7c3e8f2': [{ t: ts(9,55,1),  l:'info', m:'PostgreSQL 15.4 starting' }, { t: ts(9,55,3),  l:'info', m:'Ready to accept connections' }, { t: ts(10,11,31), l:'error', m:'auth failed from 172.18.0.5' }],
    'e5f9d2a4': [{ t: ts(11,0,0),  l:'info', m:'Grafana v10.2.3' }, { t: ts(11,0,1), l:'info', m:'HTTP Server on :3000' }],
  };
  const logLines = mockLogs[c.id] || [{ t: ts(10, 0, 0), l: 'info', m: 'Container started' }];

  const LogsView = () => {
    const [lines, setLines] = useState(logLines.map((l, i) => ({ ...l, id: i })));
    const [follow, setFollow] = useState(c.status === 'running');
    const scrollRef = useRef(null);
    const counter = useRef(lines.length);
    const pool = [{ l:'info', m:'GET /health 200 2ms' }, { l:'info', m:'GET /api/data 200 18ms' }, { l:'warn', m:'slow response: 320ms' }];

    useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [lines]);
    useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, []);
    useEffect(() => {
      if (c.status !== 'running' || !follow) return;
      let i = 0;
      const iv = setInterval(() => {
        const src = pool[i++ % pool.length];
        setLines(ls => [...ls, { ...src, t: now(), id: counter.current++ }]);
      }, 2200);
      return () => clearInterval(iv);
    }, [c.status, follow]);

    return (
      <div className="adw-terminal">
        <div className="adw-terminal__toolbar">
          <span className="adw-terminal__title">{c.name} · stdout+stderr</span>
          {c.status === 'running' && (
            <button className={`adw-terminal__btn${follow ? ' active' : ''}`} onClick={() => setFollow(f => !f)}>
              <Ico n="download" size={12}/> {follow ? 'Following' : 'Follow'}
            </button>
          )}
          <button className="adw-terminal__btn" onClick={() => setLines([])}><Ico n="trash" size={12}/> Clear</button>
        </div>
        <div className="adw-terminal__scroll" ref={scrollRef}>
          {lines.map(line => (
            <div key={line.id} className="adw-log-line">
              <span className="adw-log-ts">{line.t}</span>
              <span className={`adw-log-lvl ${line.l}`}>{line.l.toUpperCase()}</span>
              <span className={`adw-log-msg${line.l === 'error' ? ' err' : ''}`}>{line.m}</span>
            </div>
          ))}
          {follow && c.status === 'running' && <span className="adw-log-cursor"/>}
        </div>
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      {/* Sub-headerbar with name + tabs */}
      <div className="adw-detail-header">
        <StatusBadge status={c.status}/>
        <span style={{ fontWeight: 700, fontSize: '0.9375rem', color: 'var(--headerbar-fg-color)' }}>{c.name}</span>
        <div style={{ flex: 1 }}/>
        <nav className="adw-tab-bar" role="tablist">
          {CONTAINER_TABS.map(t => (
            <button key={t} role="tab" aria-selected={dtab === t} className={`adw-tab-btn${dtab === t ? ' active' : ''}`} onClick={() => setDtab(t)}>
              {TAB_LABELS[t]}
            </button>
          ))}
        </nav>
      </div>

      {dtab === 'info' && (
        <div className="adw-detail-scroll">
          {/* Actions */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {(c.status === 'stopped' || c.status === 'exited' || c.status === 'error') &&
              <button className="adw-btn adw-btn--suggested" onClick={() => onAction('start', c)}><Ico n="play" size={14}/> Start</button>}
            {(c.status === 'running' || c.status === 'paused') &&
              <button className="adw-btn adw-btn--destructive" onClick={() => onAction('stop', c)}><Ico n="stop" size={14}/> Stop</button>}
            {c.status === 'running' &&
              <button className="adw-btn" onClick={() => onAction('pause', c)}><Ico n="pause" size={14}/> Pause</button>}
            {c.status === 'paused' &&
              <button className="adw-btn" onClick={() => onAction('unpause', c)}><Ico n="play" size={14}/> Unpause</button>}
            <button className="adw-btn" onClick={() => onAction('restart', c)}><Ico n="restart" size={14}/> Restart</button>
            <button className="adw-btn adw-btn--destructive" style={{ marginLeft: 'auto' }} onClick={() => onAction('remove', c)}><Ico n="trash" size={14}/> Remove…</button>
          </div>

          <div className="adw-prefs-group">
            <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Properties</h3></div>
            <div className="adw-prefs-group__listbox">
              <PR k="Name"    v={c.name}/>
              <PR k="ID"      v={c.id} mono/>
              <PR k="Image"   v={c.image}/>
              <PR k="Command" v={c.command} mono/>
              <PR k="Status"  v={<StatusBadge status={c.status}/>}/>
              <PR k="Ports"   v={c.ports || '—'}/>
              <PR k="Restart" v={c.restart}/>
              {c.compose && <PR k="Compose" v={c.compose}/>}
            </div>
          </div>

          {c.env && c.env.length > 0 && (
            <div className="adw-prefs-group">
              <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Environment</h3></div>
              <div className="adw-prefs-group__listbox">
                {c.env.map((e, i) => {
                  const [k, ...rest] = e.split('=');
                  const v = rest.join('=');
                  const isSecret = /pass|secret|key|token/i.test(k);
                  return <PR key={i} k={k} v={isSecret ? '••••••••' : v} mono/>;
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {dtab === 'logs'     && <LogsView key={c.id}/>}
      {dtab === 'stats'    && <StatsView c={c}/>}
      {dtab === 'terminal' && (
        c.status === 'running'
          ? <TerminalView key={c.id} c={c}/>
          : <div className="adw-status-page" style={{ flex: 1 }}>
              <div className="adw-status-page__icon"><Ico n="terminal" size={80}/></div>
              <h2 className="adw-status-page__title">Not Running</h2>
              <p className="adw-status-page__desc">Start the container to open a terminal session.</p>
            </div>
      )}
      {dtab === 'inspect'  && <InspectView item={c}/>}
    </div>
  );
};

// ─── Image Detail ─────────────────────────────────────────────────────────────
const ImageDetail = ({ img, onAction }) => {
  const { useState } = React;
  const [tab, setTab] = useState('info');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      <div className="adw-detail-header">
        <span style={{ fontWeight: 700, fontSize: '0.9375rem', color: 'var(--headerbar-fg-color)' }}>{img.name}:{img.tag}</span>
        <div style={{ flex: 1 }}/>
        <nav className="adw-tab-bar" role="tablist">
          {['info', 'layers'].map(t => (
            <button key={t} role="tab" aria-selected={tab === t} className={`adw-tab-btn${tab === t ? ' active' : ''}`} onClick={() => setTab(t)}>
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </nav>
      </div>
      {tab === 'info' && (
        <div className="adw-detail-scroll">
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="adw-btn"><Ico n="play" size={14}/> Run…</button>
            <button className="adw-btn"><Ico n="download" size={14}/> Push…</button>
            <button className="adw-btn adw-btn--destructive" style={{ marginLeft: 'auto' }} onClick={() => onAction('remove', img)}><Ico n="trash" size={14}/> Remove…</button>
          </div>
          <div className="adw-prefs-group">
            <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Properties</h3></div>
            <div className="adw-prefs-group__listbox">
              <PR k="Name"    v={img.name}/>
              <PR k="Tag"     v={img.tag}/>
              <PR k="ID"      v={img.id} mono/>
              <PR k="Size"    v={img.size}/>
              <PR k="Created" v={img.created}/>
              <PR k="In Use"  v={img.inUse ? '✓ Yes' : '✗ No — can be pruned'}/>
            </div>
          </div>
        </div>
      )}
      {tab === 'layers' && <LayersView img={img}/>}
    </div>
  );
};

// ─── Volume Detail ────────────────────────────────────────────────────────────
const VolumeDetail = ({ vol, onAction }) => (
  <div className="adw-detail-scroll">
    <div style={{ display: 'flex', gap: 8 }}>
      <button className="adw-btn adw-btn--destructive" onClick={() => onAction('remove', vol)}><Ico n="trash" size={14}/> Remove…</button>
    </div>
    <div className="adw-prefs-group">
      <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Properties</h3></div>
      <div className="adw-prefs-group__listbox">
        <PR k="Name"       v={vol.name}/>
        <PR k="Driver"     v={vol.driver}/>
        <PR k="Mountpoint" v={vol.mountpoint} mono/>
        <PR k="Size"       v={vol.size}/>
        <PR k="In Use"     v={vol.inUse ? '✓ Yes' : '✗ No — can be pruned'}/>
      </div>
    </div>
  </div>
);

// ─── Network Detail ───────────────────────────────────────────────────────────
const NetworkDetail = ({ net, onAction }) => (
  <div className="adw-detail-scroll">
    <div style={{ display: 'flex', gap: 8 }}>
      {net.name !== 'bridge' && net.name !== 'host' && net.name !== 'none' &&
        <button className="adw-btn adw-btn--destructive" onClick={() => onAction('remove', net)}><Ico n="trash" size={14}/> Remove…</button>}
    </div>
    <div className="adw-prefs-group">
      <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Properties</h3></div>
      <div className="adw-prefs-group__listbox">
        <PR k="Name"       v={net.name}/>
        <PR k="ID"         v={net.id} mono/>
        <PR k="Driver"     v={net.driver}/>
        <PR k="Subnet"     v={net.subnet}/>
        <PR k="Gateway"    v={net.gateway}/>
        <PR k="Internal"   v={net.internal ? 'Yes' : 'No'}/>
        <PR k="Containers" v={`${net.containers} connected`}/>
      </div>
    </div>
  </div>
);

// ─── Empty states ─────────────────────────────────────────────────────────────
const EmptySelection = () => (
  <div className="adw-status-page" style={{ flex: 1 }}>
    <div className="adw-status-page__icon">
      <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2"/>
        <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/>
        <line x1="12" y1="12" x2="12" y2="16"/>
        <line x1="10" y1="14" x2="14" y2="14"/>
      </svg>
    </div>
    <h2 className="adw-status-page__title">No Selection</h2>
    <p className="adw-status-page__desc">Select an item from the list to view its details.</p>
  </div>
);

const EmptyList = ({ tab }) => {
  const msgs = {
    containers: { icon: 'container', title: 'No Containers',  desc: 'No containers found. Run a container to get started.' },
    images:     { icon: 'img',       title: 'No Images',      desc: 'No images found. Pull an image to get started.' },
    volumes:    { icon: 'vol',       title: 'No Volumes',     desc: 'No volumes found. Create a volume to get started.' },
    networks:   { icon: 'net',       title: 'No Networks',    desc: 'No networks configured.' },
  };
  const m = msgs[tab] || msgs.containers;
  return (
    <div className="adw-status-page" style={{ flex: 1 }}>
      <div className="adw-status-page__icon"><Ico n={m.icon} size={80}/></div>
      <h2 className="adw-status-page__title">{m.title}</h2>
      <p className="adw-status-page__desc">{m.desc}</p>
    </div>
  );
};

Object.assign(window, {
  TerminalView, StatsView, InspectView, LayersView,
  ContainerDetail, ImageDetail, VolumeDetail, NetworkDetail,
  EmptySelection, EmptyList,
});
