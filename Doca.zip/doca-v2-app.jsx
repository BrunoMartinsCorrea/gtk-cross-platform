// ─── Dashboard ────────────────────────────────────────────────────────────────
const Dashboard = ({ containers, images, volumes, networks, onNavigate }) => {
  const { useState, useEffect } = React;
  const running  = containers.filter(c=>c.status==='running').length;
  const paused   = containers.filter(c=>c.status==='paused').length;
  const stopped  = containers.filter(c=>c.status==='stopped'||c.status==='exited').length;
  const errored  = containers.filter(c=>c.status==='error').length;

  const [sysCpu,  setSysCpu]  = useState(8.4);
  const [sysMem,  setSysMem]  = useState(42.1);
  const [sysDisk, setSysDisk] = useState(61.3);

  useEffect(()=>{
    const iv=setInterval(()=>{
      setSysCpu(v=>Math.max(2,Math.min(95,v+(Math.random()-0.45)*3)));
      setSysMem(v=>Math.max(20,Math.min(90,v+(Math.random()-0.5)*0.8)));
    },2000);
    return ()=>clearInterval(iv);
  },[]);

  const MiniBar = ({ val, color }) => (
    <div style={{height:4,borderRadius:2,background:'var(--sep)',overflow:'hidden',marginTop:4}}>
      <div style={{height:'100%',width:`${val}%`,background:color,borderRadius:2,transition:'width 0.8s ease'}}/>
    </div>
  );

  const StatCard = ({ label, value, sub, color='var(--accent)', onClick }) => (
    <div className="arow" style={{cursor:onClick?'pointer':'default',flexDirection:'column',alignItems:'stretch',gap:2,padding:'14px 16px',minHeight:0}} onClick={onClick}>
      <div style={{fontSize:'22pt',fontWeight:700,color,lineHeight:1}}>{value}</div>
      <div style={{fontSize:'9pt',fontWeight:700,color:'var(--txt)',marginTop:4}}>{label}</div>
      {sub && <div style={{fontSize:'8pt',color:'var(--txt2)'}}>{sub}</div>}
    </div>
  );

  return (
    <div className="detail-scroll" style={{gap:16}}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8}}>
        <StatCard label="Running"  value={running}  color="var(--ok)"   onClick={()=>onNavigate('containers')}/>
        <StatCard label="Paused"   value={paused}   color="var(--warn)" onClick={()=>onNavigate('containers')}/>
        <StatCard label="Stopped"  value={stopped}  color="var(--dim)"  onClick={()=>onNavigate('containers')}/>
        <StatCard label="Errors"   value={errored}  color="var(--err)"  onClick={()=>onNavigate('containers')}/>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
        <StatCard label="Images"   value={images.length}   sub={`${images.filter(i=>!i.inUse).length} dangling`}  color="var(--accent)" onClick={()=>onNavigate('images')}/>
        <StatCard label="Volumes"  value={volumes.length}  sub={`${volumes.filter(v=>!v.inUse).length} unused`}   color="var(--accent)" onClick={()=>onNavigate('volumes')}/>
        <StatCard label="Networks" value={networks.length} sub={`${networks.filter(n=>n.containers>0).length} active`} color="var(--accent)" onClick={()=>onNavigate('networks')}/>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
        <div className="pref-group" style={{flex:1}}>
          <div className="pref-group-title">Host Resources</div>
          <div className="pref-rows">
            <div className="pref-row" style={{flexDirection:'column',alignItems:'stretch',gap:4,padding:'10px 14px'}}>
              <div style={{display:'flex',justifyContent:'space-between'}}><span className="pref-key" style={{width:'auto'}}>CPU</span><span style={{fontSize:'9pt',fontWeight:700,color:'var(--txt)'}}>{sysCpu.toFixed(1)}%</span></div>
              <MiniBar val={sysCpu} color="var(--accent)"/>
            </div>
            <div className="pref-row" style={{flexDirection:'column',alignItems:'stretch',gap:4,padding:'10px 14px'}}>
              <div style={{display:'flex',justifyContent:'space-between'}}><span className="pref-key" style={{width:'auto'}}>Memory</span><span style={{fontSize:'9pt',fontWeight:700,color:'var(--txt)'}}>{sysMem.toFixed(1)}%</span></div>
              <MiniBar val={sysMem} color="var(--ok)"/>
            </div>
            <div className="pref-row" style={{flexDirection:'column',alignItems:'stretch',gap:4,padding:'10px 14px'}}>
              <div style={{display:'flex',justifyContent:'space-between'}}><span className="pref-key" style={{width:'auto'}}>Disk</span><span style={{fontSize:'9pt',fontWeight:700,color:'var(--txt)'}}>{sysDisk.toFixed(1)}%</span></div>
              <MiniBar val={sysDisk} color="var(--warn)"/>
            </div>
          </div>
        </div>

        <div className="pref-group" style={{flex:1}}>
          <div className="pref-group-title">Recent Events</div>
          <div className="pref-rows">
            {EVENTS.slice(0,5).map((e,i)=>(
              <div key={i} className="pref-row" style={{gap:8,padding:'8px 12px',minHeight:0}}>
                <span style={{fontSize:'7.5pt',color:'var(--txt2)',fontFamily:'monospace',flexShrink:0}}>{e.ts}</span>
                <span style={{
                  fontSize:'7pt',padding:'1px 6px',borderRadius:4,flexShrink:0,fontWeight:700,
                  background: e.action==='start'?'var(--ok-bg)':e.action==='stop'||e.action==='die'?'var(--err-bg)':'var(--btn-bg)',
                  color: e.action==='start'?'var(--ok)':e.action==='stop'||e.action==='die'?'var(--err)':'var(--txt2)',
                }}>{e.action}</span>
                <span style={{fontSize:'8pt',color:'var(--txt)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{e.actor}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Sidebar Rows ─────────────────────────────────────────────────────────────
const ContainerRow = ({ c, selected, onSelect, onAction }) => {
  const sub = [c.image, c.id, c.ports].filter(Boolean).join(' · ');
  return (
    <div className={`arow${selected?' selected':''}`} onClick={()=>onSelect(c)}>
      <StatusBadge status={c.status}/>
      <div className="arow-text">
        <div className="arow-title">{c.name}</div>
        <div className="arow-sub">{sub}</div>
      </div>
      <div className="arow-actions" onClick={e=>e.stopPropagation()}>
        {c.status==='running'  && <button className="act-btn" title="Stop"    onClick={()=>onAction('stop',c)}><Ico n="stop"  size={15}/></button>}
        {(c.status==='stopped'||c.status==='exited'||c.status==='error') && <button className="act-btn" title="Start" onClick={()=>onAction('start',c)}><Ico n="play"  size={15}/></button>}
        {c.status==='running'  && <button className="act-btn" title="Pause"   onClick={()=>onAction('pause',c)}><Ico n="pause" size={15}/></button>}
        {c.status==='paused'   && <button className="act-btn" title="Unpause" onClick={()=>onAction('unpause',c)}><Ico n="play"  size={15}/></button>}
        <button className="act-btn danger" title="Remove" onClick={()=>onAction('remove',c)}><Ico n="trash" size={15}/></button>
      </div>
    </div>
  );
};

const ImageRow = ({ img, selected, onSelect, onAction }) => (
  <div className={`arow${selected?' selected':''}`} onClick={()=>onSelect(img)}>
    <div style={{width:32,height:32,borderRadius:8,background:'var(--btn-bg)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--txt2)',flexShrink:0}}>
      <Ico n="img" size={16}/>
    </div>
    <div className="arow-text">
      <div className="arow-title">{img.name}:{img.tag}</div>
      <div className="arow-sub">{img.id.slice(0,14)} · {img.size}{!img.inUse?' · dangling':''}</div>
    </div>
    <div className="arow-actions" onClick={e=>e.stopPropagation()}>
      <button className="act-btn danger" title="Remove" onClick={()=>onAction('remove',img)}><Ico n="trash" size={15}/></button>
    </div>
  </div>
);

const VolumeRow = ({ vol, selected, onSelect, onAction }) => (
  <div className={`arow${selected?' selected':''}`} onClick={()=>onSelect(vol)}>
    <div style={{width:32,height:32,borderRadius:8,background:'var(--btn-bg)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--txt2)',flexShrink:0}}>
      <Ico n="vol" size={16}/>
    </div>
    <div className="arow-text">
      <div className="arow-title">{vol.name}</div>
      <div className="arow-sub">{vol.driver} · {vol.size}{!vol.inUse?' · unused':''}</div>
    </div>
    <div className="arow-actions" onClick={e=>e.stopPropagation()}>
      <button className="act-btn danger" title="Remove" onClick={()=>onAction('remove',vol)}><Ico n="trash" size={15}/></button>
    </div>
  </div>
);

const NetworkRow = ({ net, selected, onSelect, onAction }) => (
  <div className={`arow${selected?' selected':''}`} onClick={()=>onSelect(net)}>
    <div style={{width:32,height:32,borderRadius:8,background:'var(--btn-bg)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--txt2)',flexShrink:0}}>
      <Ico n="net" size={16}/>
    </div>
    <div className="arow-text">
      <div className="arow-title">{net.name}</div>
      <div className="arow-sub">{net.driver} · {net.subnet}</div>
    </div>
    <div className="arow-actions" onClick={e=>e.stopPropagation()}>
      {net.name!=='bridge'&&net.name!=='host'&&net.name!=='none'&&
        <button className="act-btn danger" title="Remove" onClick={()=>onAction('remove',net)}><Ico n="trash" size={15}/></button>}
    </div>
  </div>
);

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const Sidebar = ({ tab, items, selected, onSelect, onAction, onAdd, showCompose=true }) => {
  const { useState } = React;
  const [search, setSearch] = useState('');
  const [collapsedGroups, setCollapsedGroups] = useState({});

  const q = search.toLowerCase();
  const filtered = items.filter(item => {
    const name = item.name || '';
    const image = item.image || '';
    const id = item.id || '';
    return name.toLowerCase().includes(q) || image.toLowerCase().includes(q) || id.toLowerCase().includes(q);
  });

  const toggleGroup = (g) => setCollapsedGroups(s=>({...s,[g]:!s[g]}));

  const renderRow = (item) => {
    const key = item.id || item.name;
    const sel = !!selected && (
    (item.id  !== undefined && selected.id   === item.id) ||
    (item.name !== undefined && selected.name === item.name && selected.id === undefined)
  );
    if (tab==='containers') return <ContainerRow key={key} c={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
    if (tab==='images')     return <ImageRow     key={key} img={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
    if (tab==='volumes')    return <VolumeRow    key={key} vol={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
    return                         <NetworkRow   key={key} net={item} selected={sel} onSelect={onSelect} onAction={onAction}/>;
  };

  // Compose grouping for containers tab
  let content;
  if (tab==='containers' && showCompose) {
    const groups = {};
    filtered.forEach(c => {
      const g = c.compose || '__ungrouped';
      if (!groups[g]) groups[g] = [];
      groups[g].push(c);
    });
    const names = [...Object.keys(groups).filter(g=>g!=='__ungrouped').sort(), '__ungrouped'];
    content = names.map(g => {
      const gc = groups[g];
      if (!gc || gc.length===0) return null;
      const isUngrouped = g==='__ungrouped';
      const collapsed = collapsedGroups[g];
      const allRunning = gc.every(c=>c.status==='running');
      const anyRunning = gc.some(c=>c.status==='running');
      if (isUngrouped) return gc.map(renderRow);
      return (
        <div key={g}>
          <div
            style={{display:'flex',alignItems:'center',gap:6,padding:'4px 4px 4px 2px',cursor:'pointer',borderRadius:6,marginBottom:collapsed?0:4}}
            onClick={()=>toggleGroup(g)}
          >
            <div style={{color:'var(--txt2)',transition:'transform 0.15s',transform:collapsed?'rotate(-90deg)':'rotate(0deg)'}}>
              <Ico n="chevdown" size={16}/>
            </div>
            <Ico n="compose" size={14}/>
            <span style={{fontSize:'9pt',fontWeight:700,color:'var(--txt)',flex:1}}>{g}</span>
            <span style={{
              fontSize:'7.5pt',padding:'1px 7px',borderRadius:99,fontWeight:700,
              background: allRunning?'var(--ok-bg)':anyRunning?'var(--warn-bg)':'var(--dim-bg)',
              color: allRunning?'var(--ok)':anyRunning?'var(--warn)':'var(--dim)',
            }}>
              {gc.filter(c=>c.status==='running').length}/{gc.length}
            </span>
          </div>
          {!collapsed && (
            <div style={{paddingLeft:16,display:'flex',flexDirection:'column',gap:6}}>
              {gc.map(renderRow)}
            </div>
          )}
        </div>
      );
    });
  } else {
    content = filtered.length===0 ? <EmptyList tab={tab}/> : filtered.map(renderRow);
  }

  return (
    <div style={{display:'flex',flexDirection:'column',flex:1,overflow:'hidden'}}>
      {/* Search bar */}
      <div style={{padding:'8px 10px',borderBottom:'1px solid var(--sep)',display:'flex',alignItems:'center',gap:6,background:'var(--sidebar-bg)'}}>
        <div style={{color:'var(--txt2)',flexShrink:0,display:'flex',alignItems:'center'}}><Ico n="search" size={14}/></div>
        <input
          style={{flex:1,background:'transparent',border:'none',outline:'none',fontFamily:'var(--font)',fontSize:'9pt',color:'var(--txt)'}}
          placeholder={`Filter ${tab}…`}
          value={search}
          onChange={e=>setSearch(e.target.value)}
        />
        {search && <button style={{background:'none',border:'none',cursor:'pointer',color:'var(--txt2)',padding:2,lineHeight:0}} onClick={()=>setSearch('')}><Ico n="close" size={12}/></button>}
        {onAdd && (
          <button className="act-btn" title="Create" onClick={onAdd} style={{flexShrink:0,color:'var(--accent)'}}><Ico n="add" size={16}/></button>
        )}
      </div>
      <div className="list-scroll" style={{gap:tab==='containers'?8:6}}>
        {filtered.length===0 && search ? (
          <div className="status-page" style={{paddingTop:40}}>
            <div style={{opacity:0.3,marginBottom:8}}><Ico n="search" size={40}/></div>
            <div className="status-title" style={{fontSize:'12pt'}}>No results</div>
            <div className="status-desc">No {tab} matching "{search}"</div>
          </div>
        ) : content}
      </div>
    </div>
  );
};

// ─── Main App ─────────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "viewport": "desktop",
  "runtime": "docker"
}/*EDITMODE-END*/;

function App() {
  const { useState, useEffect } = React;
  const [tweaks, setTweaksState] = useState(TWEAK_DEFAULTS);
  const setTweak = (k,v) => {
    const next = typeof k==='object'?{...tweaks,...k}:{...tweaks,[k]:v};
    setTweaksState(next);
    window.parent.postMessage({type:'__edit_mode_set_keys',edits:next},'*');
  };

  const [tab,       setTab]       = useState('home');
  const [containers,setContainers]= useState(CONTAINERS);
  const [images,    setImages]    = useState(IMAGES);
  const [volumes,   setVolumes]   = useState(VOLUMES);
  const [networks,  setNetworks]  = useState(NETWORKS);
  const [selected,  setSelected]  = useState(null);
  const [dialog,    setDialog]    = useState(null);
  const [toast,     setToast]     = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [tweaksOpen,setTweaksOpen]= useState(false);
  const [mobileView,setMobileView]= useState('list');
  const [menuOpen,  setMenuOpen]  = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [pullOpen,  setPullOpen]  = useState(false);
  const [createOpen,setCreateOpen]= useState(null); // 'container'|'volume'|'network'

  const isMobile  = tweaks.viewport==='mobile';
  const isDark    = tweaks.theme==='dark';

  useEffect(()=>{
    const h=e=>{
      if(e.data?.type==='__activate_edit_mode')   setTweaksOpen(true);
      if(e.data?.type==='__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message',h);
    window.parent.postMessage({type:'__edit_mode_available'},'*');
    return ()=>window.removeEventListener('message',h);
  },[]);

  const showToast = msg=>{ setToast(null); setTimeout(()=>setToast(msg),10); };

  const handleContainerAction = (action,c) => {
    if(action==='remove'){setDialog({type:'remove-container',item:c});return;}
    const next = {stop:'stopped',start:'running',pause:'paused',unpause:'running',restart:'running'}[action];
    if(next) {
      setContainers(cs=>cs.map(x=>x.id!==c.id?x:{...x,status:next}));
      if(selected?.id===c.id) setSelected(s=>({...s,status:next}));
    }
    const msgs={stop:'Container stopped',start:'Container started',pause:'Container paused',unpause:'Container unpaused',restart:'Container restarted'};
    showToast(msgs[action]||'Done');
  };

  const handleGenericAction = (action,item,setter,key) => {
    if(action==='remove'){setDialog({type:`remove-${key}`,item});return;}
  };

  const confirmRemove = () => {
    const{type,item}=dialog;
    if(type==='prune'){
      setContainers(cs=>cs.filter(c=>c.status==='running'));
      setImages(is=>is.filter(i=>i.inUse));
      if(!containers.find(c=>c.id===selected?.id&&c.status==='running')) setSelected(null);
      setDialog(null); showToast('System pruned'); return;
    }
    if(type==='remove-container'){setContainers(cs=>cs.filter(x=>x.id!==item.id));if(selected?.id===item.id)setSelected(null);}
    if(type==='remove-image'){    setImages(is=>is.filter(x=>x.id!==item.id));    if(selected?.id===item.id)setSelected(null);}
    if(type==='remove-volume'){   setVolumes(vs=>vs.filter(x=>x.name!==item.name));if(selected?.name===item.name)setSelected(null);}
    if(type==='remove-network'){  setNetworks(ns=>ns.filter(x=>x.id!==item.id)); if(selected?.id===item.id)setSelected(null);}
    setDialog(null); showToast('Removed');
  };

  const changeTab = t=>{ setTab(t); setSelected(null); if(isMobile)setMobileView('list'); };
  const handleSelect = item=>{ setSelected(item); if(isMobile)setMobileView('detail'); };

  const TABS = [
    {id:'home',       label:'Home',       icon:'home'},
    {id:'containers', label:'Containers', icon:'container'},
    {id:'images',     label:'Images',     icon:'img'},
    {id:'volumes',    label:'Volumes',    icon:'vol'},
    {id:'networks',   label:'Networks',   icon:'net'},
  ];

  const tabItems = tab==='containers'?containers:tab==='images'?images:tab==='volumes'?volumes:tab==='networks'?networks:[];
  const detailTitle = selected?(selected.name||selected.id):'No Selection';

  const addBtn = tab==='images'?()=>setPullOpen(true)
    :tab==='volumes'?()=>setCreateOpen('volume')
    :tab==='networks'?()=>setCreateOpen('network')
    :tab==='containers'?()=>setCreateOpen('container')
    :null;

  const runtimes = ['docker','podman','containerd'];

  return (
    <div data-theme={isDark?'dark':'light'}>
      <div className={`window ${tweaks.viewport}`}>

        {/* ── Header Bar ── */}
        <div className="hbar">
          {isMobile && mobileView==='detail' ? <>
            <button className="icon-btn" onClick={()=>setMobileView('list')}><Ico n="back" size={18}/></button>
            <div className="hbar-title">{detailTitle}</div>
            <div style={{width:34}}/>
          </> : <>
            <div className="hbar-start">
              {!isMobile && <div className="hbar-controls"><div className="wbtn close"/><div className="wbtn min"/><div className="wbtn max"/></div>}
              <div className="menu-anchor">
                <button className="icon-btn" onClick={e=>{e.stopPropagation();setMenuOpen(o=>!o);}}><Ico n="menu" size={18}/></button>
                {menuOpen && <MenuPopover onClose={()=>setMenuOpen(false)} onAbout={()=>setAboutOpen(true)}
                  onPrune={()=>setDialog({type:'prune',item:{name:'all unused resources'}})}/>}
              </div>
            </div>
            {!isMobile && (
              <div className="vs">
                {TABS.map(t=>(
                  <button key={t.id} className={`vs-btn${tab===t.id?' active':''}`} onClick={()=>changeTab(t.id)}>
                    {t.label}
                  </button>
                ))}
              </div>
            )}
            {isMobile && <div className="hbar-title">Doca</div>}
            <div className="hbar-end" style={{gap:4}}>
              {/* Runtime switcher */}
              {!isMobile && (
                <div style={{display:'flex',background:'var(--vs-active)',borderRadius:6,padding:2,gap:1}}>
                  {runtimes.map(r=>(
                    <button key={r} onClick={()=>setTweak('runtime',r)}
                      style={{padding:'3px 8px',borderRadius:4,border:'none',cursor:'pointer',fontFamily:'var(--font)',
                        fontSize:'7.5pt',fontWeight:tweaks.runtime===r?700:400,
                        background:tweaks.runtime===r?'var(--card-bg)':'transparent',
                        color:tweaks.runtime===r?'var(--txt)':'var(--txt2)',
                        boxShadow:tweaks.runtime===r?'0 1px 3px rgba(0,0,0,0.1)':'none',
                        transition:'all 0.12s',textTransform:'capitalize'}}>
                      {r}
                    </button>
                  ))}
                </div>
              )}
              {loading?<Spinner size={16}/>:
                <button className="icon-btn" onClick={()=>{setLoading(true);setTimeout(()=>{setLoading(false);showToast('Refreshed');},1200);}}><Ico n="refresh" size={18}/></button>}
              <button className="icon-btn"><Ico n="more" size={18}/></button>
            </div>
          </>}
        </div>

        {/* ── Body ── */}
        <div className="body-split">
          {/* Sidebar */}
          {tab!=='home' && (
            <div className={`sidebar${isMobile?(mobileView==='list'?' mobile-list-visible':''):''}`}>
              <Sidebar
                tab={tab} items={tabItems} selected={selected}
                onSelect={handleSelect}
                onAction={(a,i)=>{
                  if(tab==='containers') return handleContainerAction(a,i);
                  if(tab==='images')    return handleGenericAction(a,i,setImages,'image');
                  if(tab==='volumes')   return handleGenericAction(a,i,setVolumes,'volume');
                  if(tab==='networks')  return handleGenericAction(a,i,setNetworks,'network');
                }}
                onAdd={addBtn}
              />
            </div>
          )}

          {/* Detail / Home */}
          <div className={`detail-pane${isMobile?(mobileView==='detail'?' mobile-detail-visible':''):''}`}
               style={tab==='home'?{flex:1}:{}}>
            {tab==='home' ? (
              <>
                {!isMobile && (
                  <div className="detail-hbar">
                    <div className="detail-hbar-title">Overview — {tweaks.runtime.charAt(0).toUpperCase()+tweaks.runtime.slice(1)}</div>
                  </div>
                )}
                <Dashboard containers={containers} images={images} volumes={volumes} networks={networks} onNavigate={changeTab}/>
              </>
            ) : (
              <>
                {!isMobile && (
                  <div className="detail-hbar">
                    <div className="detail-hbar-title">{detailTitle}</div>
                  </div>
                )}
                {!selected ? <EmptySelection/> :
                  tab==='containers' ? <ContainerDetail c={selected} onAction={handleContainerAction}/> :
                  tab==='images'     ? <ImageDetail img={selected} onAction={(a,i)=>handleGenericAction(a,i,setImages,'image')}/> :
                  tab==='volumes'    ? <VolumeDetail vol={selected} onAction={(a,i)=>handleGenericAction(a,i,setVolumes,'volume')}/> :
                  <NetworkDetail net={selected} onAction={(a,i)=>handleGenericAction(a,i,setNetworks,'network')}/>
                }
              </>
            )}
          </div>
        </div>

        {/* Mobile bottom bar */}
        {isMobile && mobileView==='list' && (
          <div className="mobile-bottom-bar">
            {TABS.map(t=>(
              <button key={t.id} className={`mbb-btn${tab===t.id?' active':''}`} onClick={()=>changeTab(t.id)}>
                <Ico n={t.icon} size={20}/><span>{t.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* Overlays */}
        {aboutOpen  && <AboutDialog onClose={()=>setAboutOpen(false)}/>}
        {pullOpen   && <PullImageDialog onClose={()=>setPullOpen(false)} onDone={name=>{
          setImages(is=>[...is,{id:'sha256:new'+Date.now(),name:name.split(':')[0],tag:name.split(':')[1]||'latest',size:'— MB',created:new Date().toISOString().slice(0,10),inUse:false}]);
          showToast(`Image "${name}" pulled`);
        }}/>}
        {createOpen==='container' && <CreateContainerWizard images={images} onClose={()=>setCreateOpen(null)} onDone={f=>{
          const name=f.name||(f.image.split(':')[0]+'-'+Math.random().toString(36).slice(2,6));
          setContainers(cs=>[{id:'new'+Date.now().toString(36),name,image:f.image,status:'running',ports:f.ports.filter(p=>p.host).map(p=>`0.0.0.0:${p.host}→${p.container}/tcp`).join(', '),command:'',compose:null,created:new Date().toISOString(),restart:f.restart,env:f.env.filter(e=>e.k).map(e=>`${e.k}=${e.v}`)}, ...cs]);
          showToast(`Container "${name}" created`);
        }}/>}
        {createOpen==='volume'  && <CreateVolumeDialog  onClose={()=>setCreateOpen(null)} onDone={v=>{setVolumes(vs=>[v,...vs]);showToast(`Volume "${v.name}" created`);}}/>}
        {createOpen==='network' && <CreateNetworkDialog onClose={()=>setCreateOpen(null)} onDone={n=>{setNetworks(ns=>[n,...ns]);showToast(`Network "${n.name}" created`);}}/>}
        {dialog && (
          <ConfirmDialog
            title={dialog.type==='prune'?'Prune System?':`Remove ${dialog.type.replace('remove-','')}?`}
            desc={dialog.type==='prune'?'Remove all stopped containers, dangling images, unused networks, and build cache. Cannot be undone.'
              :`"${dialog.item.name||dialog.item.id}" will be permanently removed. This action cannot be undone.`}
            confirmLabel={dialog.type==='prune'?'Prune':'Remove'}
            onConfirm={confirmRemove} onCancel={()=>setDialog(null)}
          />
        )}
        {toast && <Toast key={toast+Date.now()} message={toast} onDone={()=>setToast(null)}/>}
      </div>

      {/* Tweaks */}
      {tweaksOpen && (
        <div className="tweaks-panel">
          <div className="tp-head">Tweaks<button className="icon-btn" style={{width:24,height:24}} onClick={()=>{setTweaksOpen(false);window.parent.postMessage({type:'__edit_mode_dismissed'},'*');}}><Ico n="close" size={14}/></button></div>
          <div className="tp-body">
            {[['Theme',['light','dark'],'theme'],['Viewport',['desktop','mobile'],'viewport'],['Runtime',['docker','podman','containerd'],'runtime']].map(([label,opts,key])=>(
              <div key={key} className="tp-row">
                <span className="tp-label">{label}</span>
                <div className="tp-segs">
                  {opts.map(v=><button key={v} className={`tp-seg${tweaks[key]===v?' active':''}`} onClick={()=>setTweak(key,v)}>{v.charAt(0).toUpperCase()+v.slice(1)}</button>)}
                </div>
              </div>
            ))}
            <div className="tp-row">
              <span className="tp-label">Dialogs</span>
              <div className="tp-segs" style={{flexWrap:'wrap'}}>
                <button className="tp-seg" onClick={()=>setPullOpen(true)}>Pull image</button>
                <button className="tp-seg" onClick={()=>setCreateOpen('container')}>New container</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
