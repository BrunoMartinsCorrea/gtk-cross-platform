// ─── Confirm Dialog ───────────────────────────────────────────────────────────
const ConfirmDialog = ({ title, desc, confirmLabel='Remove', onConfirm, onCancel, destructive=true }) => (
  <div className="dialog-overlay" onClick={onCancel}>
    <div className="dialog" onClick={e=>e.stopPropagation()}>
      <div className="dialog-head">
        <div className="dialog-title">{title}</div>
        <div className="dialog-desc">{desc}</div>
      </div>
      <div className="dialog-actions">
        <button className="dialog-btn accent" onClick={onCancel}>Cancel</button>
        <button className={`dialog-btn${destructive?' destructive':' accent'}`} onClick={onConfirm}>{confirmLabel}</button>
      </div>
    </div>
  </div>
);

// ─── Pull Image Dialog ────────────────────────────────────────────────────────
const PullImageDialog = ({ onClose, onDone }) => {
  const { useState, useEffect, useRef } = React;
  const [query, setQuery] = useState('');
  const [phase, setPhase] = useState('input'); // input | pulling | done
  const [layers, setLayers] = useState([]);
  const [digest, setDigest] = useState('');

  const LAYER_POOL = [
    'sha256:2a72d6','sha256:7c3f91','sha256:4e1b82',
    'sha256:9d5c47','sha256:3f8a19','sha256:1c6d35',
  ];
  const STATUSES = ['Pulling fs layer','Downloading','Download complete','Pull complete'];

  const startPull = () => {
    if (!query.trim()) return;
    const count = 3 + Math.floor(Math.random()*3);
    const initial = LAYER_POOL.slice(0,count).map(id=>({id,status:'Waiting',progress:0,done:false}));
    setLayers(initial);
    setPhase('pulling');
  };

  useEffect(() => {
    if (phase !== 'pulling') return;
    let done = 0;
    const total = layers.length;
    const timers = [];

    layers.forEach((l,i) => {
      // stagger start
      timers.push(setTimeout(() => {
        setLayers(ls => ls.map((x,j) => j===i ? {...x, status:'Downloading'} : x));

        // animate progress
        let p = 0;
        const step = setInterval(() => {
          p = Math.min(100, p + Math.random()*18 + 5);
          setLayers(ls => ls.map((x,j) => j===i ? {...x, progress:p} : x));
          if (p >= 100) {
            clearInterval(step);
            setLayers(ls => ls.map((x,j) => j===i ? {...x, status:'Pull complete', progress:100, done:true} : x));
            done++;
            if (done === total) {
              setDigest('sha256:' + Math.random().toString(36).slice(2,10) + Math.random().toString(36).slice(2,10));
              setTimeout(() => setPhase('done'), 400);
            }
          }
        }, 120 + i*30);
        timers.push({ clear: () => clearInterval(step) });
      }, i * 400));
    });

    return () => {
      timers.forEach(t => { if (t.clear) t.clear(); else clearTimeout(t); });
    };
  }, [phase]);

  return (
    <div className="dialog-overlay" onClick={phase==='input'?onClose:undefined}>
      <div className="dialog" style={{width:380}} onClick={e=>e.stopPropagation()}>
        <div className="dialog-head" style={{textAlign:'left',paddingBottom:16}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
            <div className="dialog-title" style={{textAlign:'left',marginBottom:0}}>Pull Image</div>
            {phase==='input'&&<IconBtn n="close" size={16} onClick={onClose}/>}
          </div>

          {phase==='input' && <>
            <input
              className="wizard-input" autoFocus
              placeholder="e.g. ubuntu:22.04, nginx:latest, ghcr.io/user/app:v1"
              value={query} onChange={e=>setQuery(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&startPull()}
              style={{width:'100%',marginBottom:8}}
            />
            <div style={{fontSize:'8pt',color:'var(--txt2)'}}>
              Supports Docker Hub, GHCR, ECR, and custom registries.
            </div>
          </>}

          {(phase==='pulling'||phase==='done') && (
            <div>
              <div style={{fontSize:'9.5pt',fontWeight:700,color:'var(--txt)',marginBottom:12}}>
                {query}
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                {layers.map(l=>(
                  <div key={l.id}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
                      <code style={{fontSize:'7.5pt',color:'var(--txt2)'}}>{l.id}</code>
                      <span style={{fontSize:'7.5pt',color:l.done?'var(--ok)':'var(--txt2)'}}>
                        {l.done ? '✓ '+l.status : l.status}
                      </span>
                    </div>
                    {!l.done && l.status==='Downloading' && (
                      <div style={{height:3,borderRadius:2,background:'var(--sep)',overflow:'hidden'}}>
                        <div style={{height:'100%',width:`${l.progress}%`,background:'var(--accent)',borderRadius:2,transition:'width 0.1s'}}/>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {phase==='done' && (
                <div style={{marginTop:12,padding:'8px 10px',background:'var(--ok-bg)',borderRadius:8,fontSize:'8pt',color:'var(--ok)',fontFamily:'monospace'}}>
                  Digest: {digest}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="dialog-actions">
          {phase==='input' && <>
            <button className="dialog-btn accent" onClick={onClose}>Cancel</button>
            <button className="dialog-btn accent" onClick={startPull} disabled={!query.trim()} style={{fontWeight:700}}>Pull</button>
          </>}
          {phase==='pulling' && (
            <div style={{display:'flex',alignItems:'center',gap:8,padding:'12px 16px',width:'100%',justifyContent:'center'}}>
              <Spinner size={14}/> <span style={{fontSize:'9pt',color:'var(--txt2)'}}>Pulling layers…</span>
            </div>
          )}
          {phase==='done' && (
            <button className="dialog-btn accent" style={{fontWeight:700}} onClick={()=>{onDone&&onDone(query);onClose();}}>Done</button>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Create Container Wizard ──────────────────────────────────────────────────
const CreateContainerWizard = ({ images, onClose, onDone }) => {
  const { useState } = React;
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    image: images[0]?.name+':'+images[0]?.tag || '',
    name: '',
    restart: 'no',
    network: 'bridge',
    ports: [{ host:'', container:'' }],
    volumes: [{ vol:'', mount:'' }],
    env: [{ k:'', v:'' }],
  });
  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const steps = ['Image','Config','Ports & Volumes','Environment'];
  const canNext = [
    !!form.image,
    true,
    true,
    true,
  ];

  const addRow = (field) => set(field, [...form[field], field==='env'?{k:'',v:''}:{host:'',container:''}]);
  const removeRow = (field,i) => set(field, form[field].filter((_,j)=>j!==i));
  const updateRow = (field,i,k,v) => set(field, form[field].map((r,j)=>j===i?{...r,[k]:v}:r));

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" style={{width:420}} onClick={e=>e.stopPropagation()}>
        <div className="dialog-head" style={{textAlign:'left',paddingBottom:0}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16}}>
            <div className="dialog-title" style={{marginBottom:0,textAlign:'left'}}>New Container</div>
            <IconBtn n="close" size={16} onClick={onClose}/>
          </div>

          {/* Step indicator */}
          <div style={{display:'flex',gap:4,marginBottom:20}}>
            {steps.map((s,i)=>(
              <div key={i} style={{flex:1,height:3,borderRadius:2,background:i<=step?'var(--accent)':'var(--sep)',transition:'background 0.2s'}}/>
            ))}
          </div>
          <div style={{fontSize:'8.5pt',fontWeight:700,color:'var(--accent)',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:14}}>
            Step {step+1} of {steps.length} — {steps[step]}
          </div>

          {/* Step 0: Image */}
          {step===0 && (
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              <label className="wizard-label">Image</label>
              <input className="wizard-input" placeholder="nginx:latest" value={form.image} onChange={e=>set('image',e.target.value)} autoFocus/>
              <div style={{display:'flex',flexDirection:'column',gap:4,maxHeight:160,overflowY:'auto'}}>
                {images.map(img=>(
                  <button key={img.id} className={`arow${form.image===img.name+':'+img.tag?' selected':''}`}
                    style={{border:'1px solid var(--card-border)',padding:'8px 12px',cursor:'pointer',minHeight:0,gap:8}}
                    onClick={()=>set('image',img.name+':'+img.tag)}>
                    <div style={{width:28,height:28,borderRadius:6,background:'var(--btn-bg)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                      <Ico n="img" size={15}/>
                    </div>
                    <div className="arow-text">
                      <div className="arow-title" style={{fontSize:'9pt'}}>{img.name}:{img.tag}</div>
                      <div className="arow-sub">{img.size}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 1: Config */}
          {step===1 && (
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              <div><label className="wizard-label">Container Name <span style={{fontWeight:400,color:'var(--txt2)'}}>(optional)</span></label>
                <input className="wizard-input" placeholder="my-container" value={form.name} onChange={e=>set('name',e.target.value)}/></div>
              <div><label className="wizard-label">Restart Policy</label>
                <select className="wizard-input" value={form.restart} onChange={e=>set('restart',e.target.value)}>
                  {['no','always','unless-stopped','on-failure'].map(o=><option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div><label className="wizard-label">Network</label>
                <select className="wizard-input" value={form.network} onChange={e=>set('network',e.target.value)}>
                  {['bridge','host','none','web-stack','monitoring'].map(o=><option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Step 2: Ports & Volumes */}
          {step===2 && (
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div>
                <div style={{display:'flex',alignItems:'center',marginBottom:6}}>
                  <label className="wizard-label" style={{flex:1,marginBottom:0}}>Port Mappings</label>
                  <button className="log-tb-btn" onClick={()=>addRow('ports')} style={{padding:'3px 8px',fontSize:'7.5pt'}}>+ Add</button>
                </div>
                {form.ports.map((p,i)=>(
                  <div key={i} style={{display:'flex',gap:6,marginBottom:6,alignItems:'center'}}>
                    <input className="wizard-input" style={{flex:1}} placeholder="Host port" value={p.host} onChange={e=>updateRow('ports',i,'host',e.target.value)}/>
                    <span style={{color:'var(--txt2)',fontSize:'10pt'}}>→</span>
                    <input className="wizard-input" style={{flex:1}} placeholder="Container port" value={p.container} onChange={e=>updateRow('ports',i,'container',e.target.value)}/>
                    <button className="act-btn danger" onClick={()=>removeRow('ports',i)}><Ico n="trash" size={13}/></button>
                  </div>
                ))}
              </div>
              <div>
                <div style={{display:'flex',alignItems:'center',marginBottom:6}}>
                  <label className="wizard-label" style={{flex:1,marginBottom:0}}>Volume Mounts</label>
                  <button className="log-tb-btn" onClick={()=>set('volumes',[...form.volumes,{vol:'',mount:''}])} style={{padding:'3px 8px',fontSize:'7.5pt'}}>+ Add</button>
                </div>
                {form.volumes.map((v,i)=>(
                  <div key={i} style={{display:'flex',gap:6,marginBottom:6,alignItems:'center'}}>
                    <input className="wizard-input" style={{flex:1}} placeholder="Volume / host path" value={v.vol} onChange={e=>updateRow('volumes',i,'vol',e.target.value)}/>
                    <span style={{color:'var(--txt2)',fontSize:'10pt'}}>:</span>
                    <input className="wizard-input" style={{flex:1}} placeholder="Mount path" value={v.mount} onChange={e=>updateRow('volumes',i,'mount',e.target.value)}/>
                    <button className="act-btn danger" onClick={()=>removeRow('volumes',i)}><Ico n="trash" size={13}/></button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Env */}
          {step===3 && (
            <div>
              <div style={{display:'flex',alignItems:'center',marginBottom:6}}>
                <label className="wizard-label" style={{flex:1,marginBottom:0}}>Environment Variables</label>
                <button className="log-tb-btn" onClick={()=>addRow('env')} style={{padding:'3px 8px',fontSize:'7.5pt'}}>+ Add</button>
              </div>
              {form.env.map((e,i)=>(
                <div key={i} style={{display:'flex',gap:6,marginBottom:6,alignItems:'center'}}>
                  <input className="wizard-input" style={{flex:1}} placeholder="KEY" value={e.k} onChange={v=>updateRow('env',i,'k',v.target.value)}/>
                  <span style={{color:'var(--txt2)'}}>=</span>
                  <input className="wizard-input" style={{flex:1}} placeholder="value" value={e.v} onChange={v=>updateRow('env',i,'v',v.target.value)}/>
                  <button className="act-btn danger" onClick={()=>removeRow('env',i)}><Ico n="trash" size={13}/></button>
                </div>
              ))}
              <div style={{marginTop:12,padding:'10px 12px',background:'var(--ok-bg)',borderRadius:8,fontSize:'8pt',color:'var(--ok)'}}>
                Ready to create <strong>{form.name||form.image.split(':')[0]}</strong> from <strong>{form.image}</strong>
                {form.ports.filter(p=>p.host).length>0 && ` · ${form.ports.filter(p=>p.host).length} port(s)`}
                {form.volumes.filter(v=>v.vol).length>0 && ` · ${form.volumes.filter(v=>v.vol).length} mount(s)`}
              </div>
            </div>
          )}
        </div>

        <div className="dialog-actions">
          <button className="dialog-btn accent" onClick={step===0?onClose:()=>setStep(s=>s-1)}>{step===0?'Cancel':'Back'}</button>
          {step<steps.length-1
            ? <button className="dialog-btn accent" style={{fontWeight:700}} disabled={!canNext[step]} onClick={()=>setStep(s=>s+1)}>Next</button>
            : <button className="dialog-btn accent" style={{fontWeight:700}} onClick={()=>{onDone&&onDone(form);onClose();}}>Create</button>}
        </div>
      </div>
    </div>
  );
};

// ─── Create Volume Dialog ─────────────────────────────────────────────────────
const CreateVolumeDialog = ({ onClose, onDone }) => {
  const { useState } = React;
  const [name, setName] = useState('');
  const [driver, setDriver] = useState('local');
  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" style={{width:340}} onClick={e=>e.stopPropagation()}>
        <div className="dialog-head" style={{textAlign:'left'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
            <div className="dialog-title" style={{marginBottom:0,textAlign:'left'}}>Create Volume</div>
            <IconBtn n="close" size={16} onClick={onClose}/>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            <div><label className="wizard-label">Name</label>
              <input className="wizard-input" placeholder="my-volume" value={name} onChange={e=>setName(e.target.value)} autoFocus/></div>
            <div><label className="wizard-label">Driver</label>
              <select className="wizard-input" value={driver} onChange={e=>setDriver(e.target.value)}>
                {['local','nfs','tmpfs'].map(o=><option key={o} value={o}>{o}</option>)}
              </select></div>
          </div>
        </div>
        <div className="dialog-actions">
          <button className="dialog-btn accent" onClick={onClose}>Cancel</button>
          <button className="dialog-btn accent" style={{fontWeight:700}} disabled={!name.trim()}
            onClick={()=>{onDone&&onDone({name:name.trim(),driver,mountpoint:`/var/lib/docker/volumes/${name}/_data`,size:'0 B',inUse:false});onClose();}}>
            Create
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Create Network Dialog ────────────────────────────────────────────────────
const CreateNetworkDialog = ({ onClose, onDone }) => {
  const { useState } = React;
  const [name, setName] = useState('');
  const [driver, setDriver] = useState('bridge');
  const [subnet, setSubnet] = useState('');
  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" style={{width:340}} onClick={e=>e.stopPropagation()}>
        <div className="dialog-head" style={{textAlign:'left'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
            <div className="dialog-title" style={{marginBottom:0,textAlign:'left'}}>Create Network</div>
            <IconBtn n="close" size={16} onClick={onClose}/>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            <div><label className="wizard-label">Name</label>
              <input className="wizard-input" placeholder="my-network" value={name} onChange={e=>setName(e.target.value)} autoFocus/></div>
            <div><label className="wizard-label">Driver</label>
              <select className="wizard-input" value={driver} onChange={e=>setDriver(e.target.value)}>
                {['bridge','overlay','macvlan','ipvlan'].map(o=><option key={o} value={o}>{o}</option>)}
              </select></div>
            <div><label className="wizard-label">Subnet <span style={{fontWeight:400,color:'var(--txt2)'}}>(optional)</span></label>
              <input className="wizard-input" placeholder="172.20.0.0/16" value={subnet} onChange={e=>setSubnet(e.target.value)}/></div>
          </div>
        </div>
        <div className="dialog-actions">
          <button className="dialog-btn accent" onClick={onClose}>Cancel</button>
          <button className="dialog-btn accent" style={{fontWeight:700}} disabled={!name.trim()}
            onClick={()=>{onDone&&onDone({id:'new-'+Date.now(),name:name.trim(),driver,subnet:subnet||'172.20.0.0/16',gateway:'172.20.0.1',internal:false,containers:0});onClose();}}>
            Create
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Menu Popover ─────────────────────────────────────────────────────────────
const MenuPopover = ({ onClose, onAbout, onPrune, onSettings }) => {
  const { useEffect } = React;
  useEffect(()=>{
    const h=()=>onClose();
    setTimeout(()=>window.addEventListener('click',h),0);
    return ()=>window.removeEventListener('click',h);
  },[]);
  return (
    <div className="menu-pop" onClick={e=>e.stopPropagation()}>
      <button className="menu-item" onClick={()=>{onPrune();onClose();}}><Ico n="trash" size={15}/> Prune System…</button>
      <button className="menu-item" onClick={()=>{onSettings&&onSettings();onClose();}}><Ico n="settings" size={15}/> Preferences</button>
      <div className="menu-sep"/>
      <button className="menu-item" onClick={()=>{onAbout();onClose();}}><Ico n="info" size={15}/> About Doca</button>
    </div>
  );
};

// ─── About Dialog ─────────────────────────────────────────────────────────────
const AboutDialog = ({ onClose }) => (
  <div className="about-overlay" onClick={onClose}>
    <div className="about-win" onClick={e=>e.stopPropagation()}>
      <div className="about-hbar">
        <span className="about-hbar-title">About</span>
        <IconBtn n="close" size={15} onClick={onClose}/>
      </div>
      <div className="about-scroll">
        <div className="about-hero">
          <div className="about-icon">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
              <polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>
            </svg>
          </div>
          <div className="about-appname">Doca</div>
          <div className="about-version">Version 0.2.0 (build 20260426)</div>
          <div className="about-desc">A native GNOME application for managing Docker, Podman, and containerd containers.</div>
        </div>
        <div className="about-section">
          <div className="about-section-title">Details</div>
          <div className="about-rows">
            <div className="about-row"><span className="about-row-key">Runtime</span><span className="about-row-val">Docker 27.0.1</span></div>
            <div className="about-row"><span className="about-row-key">GTK</span><span className="about-row-val">4.14.1</span></div>
            <div className="about-row"><span className="about-row-key">libadwaita</span><span className="about-row-val">1.5.0</span></div>
            <div className="about-row"><span className="about-row-key">Platform</span><span className="about-row-val">Linux x86_64</span></div>
          </div>
        </div>
        <div className="about-section">
          <div className="about-section-title">Credits</div>
          <div className="about-rows">
            <div className="about-row"><span className="about-row-key">Developer</span><span className="about-row-val">Your Name</span></div>
            <div className="about-row"><span className="about-row-key">Design</span><span className="about-row-val">GNOME HIG</span></div>
          </div>
        </div>
        <div className="about-section">
          <div className="about-section-title">Links</div>
          <div className="about-rows">
            <a className="about-link-row" href="#" onClick={e=>e.preventDefault()}>
              <Ico n="compose" size={14}/> Source Code on GitHub
            </a>
            <a className="about-link-row" href="#" onClick={e=>e.preventDefault()}>
              <Ico n="warn" size={14}/> Report an Issue
            </a>
          </div>
        </div>
        <div className="about-legal">Released under the <strong>GNU General Public License v3.0</strong>.<br/>© 2026 Doca Contributors.</div>
      </div>
    </div>
  </div>
);

Object.assign(window, {
  ConfirmDialog, PullImageDialog, CreateContainerWizard,
  CreateVolumeDialog, CreateNetworkDialog, MenuPopover, AboutDialog,
});
