// ─── SVG Icon paths ───────────────────────────────────────────────────────────
const PATHS = {
  play:      'M8 5v14l11-7z',
  stop:      'M6 6h12v12H6z',
  pause:     'M6 19h4V5H6v14zm8-14v14h4V5h-4z',
  trash:     'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zm2-13h8l-1-2H9L8 6z',
  refresh:   'M17.65 6.35A8 8 0 1019 12h-2a6 6 0 11-1.65-4.35L13 10h7V3l-2.35 3.35z',
  close:     'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  back:      'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  more:      'M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
  restart:   'M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z',
  check:     'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  info:      'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z',
  img:       'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
  vol:       'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
  net:       'M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z',
  moon:      'M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z',
  add:       'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  search:    'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
  terminal:  'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12zM6.99 11.5l1.42-1.41L11 12.67l-2.59 2.58L7 13.83l1.58-1.58L6.99 11.5zM13 15h4v-1.5h-4V15z',
  chart:     'M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z',
  eye:       'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z',
  layers:    'M11.99 18.54l-7.37-5.73L3 14.07l9 7 9-7-1.63-1.27-7.38 5.74zM12 16l7.36-5.73L21 9l-9-7-9 7 1.63 1.27L12 16z',
  compose:   'M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9H9V9h10v2zm-4 4H9v-2h6v2zm4-8H9V5h10v2z',
  home:      'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
  chevdown:  'M7 10l5 5 5-5z',
  chevright: 'M10 17l5-5-5-5v10z',
  copy:      'M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z',
  download:  'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
  warn:      'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
  settings:  'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
};

// ─── Icon Component ───────────────────────────────────────────────────────────
const Ico = ({ n, size = 16 }) => {
  if (!n) return null;
  if (n === 'menu') return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <line x1="3" y1="6" x2="21" y2="6"/>
      <line x1="3" y1="12" x2="21" y2="12"/>
      <line x1="3" y1="18" x2="21" y2="18"/>
    </svg>
  );
  if (n === 'container') return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
      <line x1="12" y1="22.08" x2="12" y2="12"/>
    </svg>
  );
  const d = PATHS[n];
  if (!d) return <svg width={size} height={size} viewBox="0 0 24 24"/>;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d={d}/>
    </svg>
  );
};

// ─── Status Badge ─────────────────────────────────────────────────────────────
const StatusBadge = ({ status }) => {
  const labels = {
    running: 'Running', paused: 'Paused', stopped: 'Stopped',
    exited: 'Exited', dead: 'Dead', error: 'Error',
    created: 'Created', restarting: 'Restarting',
  };
  return (
    <span className={`adw-badge adw-badge--${status}`}>
      {labels[status] || status}
    </span>
  );
};

// ─── Prefs Row ────────────────────────────────────────────────────────────────
const PR = ({ k, v, mono = false }) => (
  <div className="adw-pref-row">
    <span className="adw-pref-row__key">{k}</span>
    <span className={`adw-pref-row__val${mono ? ' mono' : ''}`}>{v}</span>
  </div>
);

// ─── Spinner ──────────────────────────────────────────────────────────────────
const Spinner = ({ size = 16 }) => (
  <div className="adw-spinner" style={{ width: size, height: size }} role="status" aria-label="Loading"/>
);

// ─── Icon Button (window-color variant) ───────────────────────────────────────
const IconBtn = ({ n, size = 18, title, onClick, className = '' }) => (
  <button className={`adw-icon-btn adw-icon-btn--window ${className}`} title={title} onClick={onClick} aria-label={title}>
    <Ico n={n} size={size}/>
  </button>
);

// ─── Mock timestamp helper ────────────────────────────────────────────────────
const now = () => {
  const d = new Date();
  return [d.getHours(), d.getMinutes(), d.getSeconds()]
    .map(n => String(n).padStart(2, '0')).join(':');
};

// ─── Mock Data ────────────────────────────────────────────────────────────────
const CONTAINERS = [
  { id:'a3f9b2c1', name:'nginx-proxy',  image:'nginx:latest',      status:'running', ports:'0.0.0.0:80→80/tcp, 443→443/tcp', command:"nginx -g 'daemon off;'", compose:'web-stack',  created:'2024-01-15T09:00:00Z', restart:'always',          env:['NGINX_HOST=example.com','NGINX_PORT=80','TZ=UTC'] },
  { id:'b7c3e8f2', name:'postgres-db',  image:'postgres:15',       status:'running', ports:'5432/tcp',                        command:'docker-entrypoint.sh postgres', compose:'web-stack',  created:'2024-01-15T09:01:00Z', restart:'always',     env:['POSTGRES_DB=appdb','POSTGRES_USER=app','POSTGRES_PASSWORD=secret123'] },
  { id:'c2d4f6e8', name:'redis-cache',  image:'redis:alpine',      status:'paused',  ports:'6379/tcp',                        command:'redis-server',                compose:'web-stack',  created:'2024-01-15T09:02:00Z', restart:'unless-stopped', env:['REDIS_MAXMEMORY=256mb'] },
  { id:'d8e1a3c5', name:'app-worker',   image:'myapp:dev',         status:'stopped', ports:'',                                command:'python worker.py',            compose:'web-stack',  created:'2024-01-15T09:03:00Z', restart:'on-failure',  env:['WORKER_CONCURRENCY=4','DATABASE_URL=postgresql://app:secret123@postgres-db/appdb'] },
  { id:'e5f9d2a4', name:'monitoring',   image:'grafana/grafana:10', status:'running', ports:'0.0.0.0:3000→3000/tcp',           command:'/run.sh',                    compose:'monitoring', created:'2024-01-10T08:00:00Z', restart:'unless-stopped', env:['GF_SECURITY_ADMIN_PASSWORD=admin'] },
  { id:'f1b7c3e9', name:'prometheus',   image:'prom/prometheus:v2', status:'running', ports:'0.0.0.0:9090→9090/tcp',           command:'/bin/prometheus',            compose:'monitoring', created:'2024-01-10T08:01:00Z', restart:'unless-stopped', env:['PROMETHEUS_RETENTION=15d'] },
  { id:'a1b2c3d4', name:'broken-svc',   image:'badimage:v1',        status:'error',   ports:'',                                command:'./start.sh',                 compose:null,         created:'2024-01-20T12:00:00Z', restart:'no',          env:[] },
];

const IMAGES = [
  { id:'sha256:a3f9b2c1d4e5', name:'nginx',           tag:'latest', size:'142 MB', created:'2024-01-15', inUse:true  },
  { id:'sha256:b7c3e8f2a1d9', name:'postgres',         tag:'15',     size:'379 MB', created:'2024-01-10', inUse:true  },
  { id:'sha256:c2d4f6e8b1a7', name:'redis',            tag:'alpine', size:'31 MB',  created:'2024-01-20', inUse:true  },
  { id:'sha256:d8e1a3c5f7b2', name:'grafana/grafana',  tag:'10',     size:'408 MB', created:'2024-01-05', inUse:true  },
  { id:'sha256:e5f9d2a4c6b8', name:'prom/prometheus',  tag:'v2',     size:'220 MB', created:'2024-01-05', inUse:true  },
  { id:'sha256:f1b7e3c9d5a2', name:'myapp',            tag:'dev',    size:'614 MB', created:'2024-01-18', inUse:true  },
  { id:'sha256:a0b1c2d3e4f5', name:'alpine',           tag:'latest', size:'7.8 MB', created:'2023-12-01', inUse:false },
  { id:'sha256:b1c2d3e4f5a0', name:'ubuntu',           tag:'22.04',  size:'77 MB',  created:'2023-11-15', inUse:false },
];

const IMAGE_LAYERS = {
  'sha256:a3f9b2c1d4e5': [
    { id:'sha256:2a72d6', cmd:'FROM debian:bookworm-slim',                              size:'28.3 MB' },
    { id:'sha256:7c3f91', cmd:'RUN apt-get update && apt-get install -y nginx',         size:'89.4 MB' },
    { id:'sha256:4e1b82', cmd:'COPY nginx.conf /etc/nginx/nginx.conf',                 size:'2.1 kB'  },
    { id:'sha256:9d5c47', cmd:'RUN ln -sf /dev/stdout /var/log/nginx/access.log',      size:'0 B'     },
    { id:'sha256:3f8a19', cmd:'EXPOSE 80 443',                                         size:'0 B'     },
    { id:'sha256:1c6d35', cmd:'CMD ["nginx", "-g", "daemon off;"]',                    size:'0 B'     },
  ],
};

const VOLUMES = [
  { name:'postgres-data',   driver:'local', mountpoint:'/var/lib/docker/volumes/postgres-data/_data',   size:'2.3 GB',  inUse:true  },
  { name:'grafana-storage', driver:'local', mountpoint:'/var/lib/docker/volumes/grafana-storage/_data', size:'148 MB',  inUse:true  },
  { name:'redis-dump',      driver:'local', mountpoint:'/var/lib/docker/volumes/redis-dump/_data',      size:'12 MB',   inUse:false },
  { name:'prometheus-data', driver:'local', mountpoint:'/var/lib/docker/volumes/prometheus-data/_data', size:'890 MB',  inUse:true  },
];

const NETWORKS = [
  { id:'a1b2c3d4', name:'bridge',     driver:'bridge', subnet:'172.17.0.0/16', gateway:'172.17.0.1', internal:false, containers:2 },
  { id:'b2c3d4e5', name:'web-stack',  driver:'bridge', subnet:'172.18.0.0/16', gateway:'172.18.0.1', internal:false, containers:4 },
  { id:'c3d4e5f6', name:'monitoring', driver:'bridge', subnet:'172.19.0.0/16', gateway:'172.19.0.1', internal:false, containers:2 },
  { id:'d4e5f6a1', name:'host',       driver:'host',   subnet:'N/A',           gateway:'N/A',         internal:false, containers:0 },
  { id:'e5f6a1b2', name:'none',       driver:'null',   subnet:'N/A',           gateway:'N/A',         internal:true,  containers:0 },
];

const EVENTS = [
  { ts:'10:24:01', type:'container', action:'start',   actor:'nginx-proxy',  id:'a3f9b2c1' },
  { ts:'10:24:00', type:'container', action:'start',   actor:'postgres-db',  id:'b7c3e8f2' },
  { ts:'10:23:58', type:'network',   action:'connect', actor:'web-stack',    id:'b2c3d4e5' },
  { ts:'10:20:11', type:'image',     action:'pull',    actor:'nginx:latest', id:'sha256:a3f9' },
  { ts:'10:15:00', type:'container', action:'stop',    actor:'app-worker',   id:'d8e1a3c5' },
  { ts:'10:14:55', type:'container', action:'die',     actor:'app-worker',   id:'d8e1a3c5' },
  { ts:'10:10:02', type:'volume',    action:'create',  actor:'postgres-data',id:'postgres-data' },
];

const INSPECT_JSON = (c) => JSON.stringify({
  Id: c.id + 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  Created: c.created,
  State: { Status: c.status, Running: c.status === 'running', Pid: 1234 },
  Name: '/' + c.name,
  Image: 'sha256:' + c.id + 'xxxxxxx',
  Config: { Env: c.env, Cmd: c.command.split(' '), Image: c.image },
  HostConfig: { NetworkMode: 'bridge', RestartPolicy: { Name: c.restart } },
  NetworkSettings: { Networks: { bridge: { IPAddress: '172.18.0.2', Gateway: '172.18.0.1' } } },
  Mounts: c.compose ? [{ Type:'volume', Name: c.compose+'-data', Destination:'/data' }] : [],
}, null, 2);

Object.assign(window, {
  Ico, StatusBadge, PR, Spinner, IconBtn, now,
  CONTAINERS, IMAGES, IMAGE_LAYERS, VOLUMES, NETWORKS, EVENTS, INSPECT_JSON,
});
