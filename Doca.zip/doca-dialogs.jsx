// ─── AdwAlertDialog (confirm) ─────────────────────────────────────────────────
const ConfirmDialog = ({ title, desc, confirmLabel = 'Remove', onConfirm, onCancel, destructive = true }) => (
  <div className="adw-scrim" onClick={onCancel} role="dialog" aria-modal="true" aria-labelledby="dlg-title">
    <div className="adw-dialog adw-dialog--alert" onClick={e => e.stopPropagation()}>
      <div className="adw-dialog__header">
        <h2 className="adw-dialog__title" id="dlg-title">{title}</h2>
      </div>
      <div className="adw-dialog__body">{desc}</div>
      <div className="adw-dialog__footer">
        <button className="adw-btn" onClick={onCancel}>Cancel</button>
        <button className={`adw-btn${destructive ? ' adw-btn--destructive' : ' adw-btn--suggested'}`} onClick={onConfirm}>
          {confirmLabel}
        </button>
      </div>
    </div>
  </div>
);

// ─── Pull Image Dialog ────────────────────────────────────────────────────────
const PullImageDialog = ({ onClose, onDone }) => {
  const { useState, useEffect } = React;
  const [query, setQuery] = useState('');
  const [phase, setPhase] = useState('input');
  const [layers, setLayers] = useState([]);
  const [digest, setDigest] = useState('');

  const LAYER_IDS = ['sha256:2a72d6', 'sha256:7c3f91', 'sha256:4e1b82', 'sha256:9d5c47', 'sha256:3f8a19'];

  const startPull = () => {
    if (!query.trim()) return;
    const count = 3 + Math.floor(Math.random() * 3);
    setLayers(LAYER_IDS.slice(0, count).map(id => ({ id, status: 'Waiting', progress: 0, done: false })));
    setPhase('pulling');
  };

  useEffect(() => {
    if (phase !== 'pulling') return;
    let done = 0;
    const total = layers.length;
    const timers = [];

    layers.forEach((l, i) => {
      timers.push(setTimeout(() => {
        setLayers(ls => ls.map((x, j) => j === i ? { ...x, status: 'Downloading' } : x));
        let p = 0;
        const step = setInterval(() => {
          p = Math.min(100, p + Math.random() * 18 + 5);
          setLayers(ls => ls.map((x, j) => j === i ? { ...x, progress: p } : x));
          if (p >= 100) {
            clearInterval(step);
            setLayers(ls => ls.map((x, j) => j === i ? { ...x, status: 'Pull complete', progress: 100, done: true } : x));
            done++;
            if (done === total) {
              setDigest('sha256:' + Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10));
              setTimeout(() => setPhase('done'), 400);
            }
          }
        }, 120 + i * 30);
        timers.push({ clear: () => clearInterval(step) });
      }, i * 400));
    });

    return () => timers.forEach(t => { if (t.clear) t.clear(); else clearTimeout(t); });
  }, [phase]);

  return (
    <div className="adw-scrim" onClick={phase === 'input' ? onClose : undefined} role="dialog" aria-modal="true" aria-labelledby="pull-title">
      <div className="adw-dialog" style={{ maxWidth: 400 }} onClick={e => e.stopPropagation()}>
        <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
          <h2 className="adw-dialog__title" id="pull-title">Pull Image</h2>
          {phase === 'input' && <IconBtn n="close" size={16} onClick={onClose}/>}
        </div>
        <div className="adw-dialog__body">
          {phase === 'input' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <input
                className="adw-entry" autoFocus
                placeholder="e.g. ubuntu:22.04, nginx:latest"
                value={query} onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && startPull()}
              />
              <p style={{ fontSize: '0.8125rem', color: 'var(--window-fg-color)', opacity: 0.55 }}>
                Supports Docker Hub, GHCR, ECR, and custom registries.
              </p>
            </div>
          )}
          {(phase === 'pulling' || phase === 'done') && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <p style={{ fontWeight: 700, fontSize: '0.9375rem', marginBottom: 4 }}>{query}</p>
              {layers.map(l => (
                <div key={l.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <code style={{ fontSize: '0.75rem', color: 'var(--window-fg-color)', opacity: 0.55, fontFamily: 'var(--font-mono)' }}>{l.id}</code>
                    <span style={{ fontSize: '0.75rem', color: l.done ? 'var(--success-color)' : 'var(--window-fg-color)', opacity: l.done ? 1 : 0.55 }}>
                      {l.done ? '✓ ' : ''}{l.status}
                    </span>
                  </div>
                  {!l.done && l.status === 'Downloading' && (
                    <div style={{ height: 3, borderRadius: 2, background: 'var(--border-color)', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${l.progress}%`, background: 'var(--accent-bg-color)', borderRadius: 2, transition: 'width 0.1s' }}/>
                    </div>
                  )}
                </div>
              ))}
              {phase === 'done' && (
                <div style={{ marginTop: 4, padding: '8px 10px', background: 'rgba(38,162,105,0.1)', borderRadius: 8, fontSize: '0.75rem', color: 'var(--success-color)', fontFamily: 'var(--font-mono)' }}>
                  Digest: {digest}
                </div>
              )}
            </div>
          )}
        </div>
        <div className="adw-dialog__footer">
          {phase === 'input' && (
            <>
              <button className="adw-btn" onClick={onClose}>Cancel</button>
              <button className="adw-btn adw-btn--suggested" onClick={startPull} disabled={!query.trim()}>Pull</button>
            </>
          )}
          {phase === 'pulling' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', justifyContent: 'center', padding: '4px 0' }}>
              <Spinner size={14}/>
              <span style={{ fontSize: '0.9375rem', color: 'var(--window-fg-color)', opacity: 0.55 }}>Pulling layers…</span>
            </div>
          )}
          {phase === 'done' && (
            <button className="adw-btn adw-btn--suggested" onClick={() => { onDone && onDone(query); onClose(); }}>Done</button>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Create Container Wizard ──────────────────────────────────────────────────
const CreateContainerWizard = ({ images, onClose, onDone }) => {
  const { useState } = React;
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    image: images[0] ? images[0].name + ':' + images[0].tag : '',
    name: '', restart: 'no', network: 'bridge',
    ports: [{ host: '', container: '' }],
    volumes: [{ vol: '', mount: '' }],
    env: [{ k: '', v: '' }],
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const steps = ['Image', 'Config', 'Ports & Volumes', 'Environment'];
  const canNext = [!!form.image, true, true, true];

  const addRow = (field) => set(field, [...form[field], field === 'env' ? { k: '', v: '' } : { host: '', container: '' }]);
  const removeRow = (field, i) => set(field, form[field].filter((_, j) => j !== i));
  const updateRow = (field, i, k, v) => set(field, form[field].map((r, j) => j === i ? { ...r, [k]: v } : r));

  return (
    <div className="adw-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="wizard-title">
      <div className="adw-dialog" style={{ maxWidth: 440 }} onClick={e => e.stopPropagation()}>
        <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
          <h2 className="adw-dialog__title" id="wizard-title">New Container</h2>
          <IconBtn n="close" size={16} onClick={onClose}/>
        </div>
        <div className="adw-dialog__body">
          {/* Progress bar */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 16 }}>
            {steps.map((s, i) => (
              <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= step ? 'var(--accent-bg-color)' : 'var(--border-color)', transition: 'background 0.2s' }}/>
            ))}
          </div>
          <p style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent-color)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 14 }}>
            Step {step + 1} of {steps.length} — {steps[step]}
          </p>

          {step === 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div>
                <label className="adw-entry-label">Image</label>
                <input className="adw-entry" placeholder="nginx:latest" value={form.image} onChange={e => set('image', e.target.value)} autoFocus/>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 160, overflowY: 'auto' }}>
                {images.map(img => (
                  <div key={img.id}
                    className={`adw-action-row${form.image === img.name + ':' + img.tag ? ' selected' : ''}`}
                    style={{ minHeight: 48, cursor: 'pointer' }}
                    onClick={() => set('image', img.name + ':' + img.tag)}>
                    <div className="adw-action-row__prefix"><Ico n="img" size={16}/></div>
                    <div className="adw-action-row__body">
                      <span className="adw-action-row__title" style={{ fontSize: '0.875rem' }}>{img.name}:{img.tag}</span>
                      <span className="adw-action-row__subtitle">{img.size}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label className="adw-entry-label">Container Name <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>(optional)</span></label>
                <input className="adw-entry" placeholder="my-container" value={form.name} onChange={e => set('name', e.target.value)}/>
              </div>
              <div>
                <label className="adw-entry-label">Restart Policy</label>
                <select className="adw-entry" value={form.restart} onChange={e => set('restart', e.target.value)}>
                  {['no', 'always', 'unless-stopped', 'on-failure'].map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="adw-entry-label">Network</label>
                <select className="adw-entry" value={form.network} onChange={e => set('network', e.target.value)}>
                  {['bridge', 'host', 'none', 'web-stack', 'monitoring'].map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                  <label className="adw-entry-label" style={{ flex: 1, marginBottom: 0 }}>Port Mappings</label>
                  <button className="adw-btn adw-btn--flat" style={{ height: 28, padding: '0 10px', fontSize: '0.8125rem' }} onClick={() => addRow('ports')}>+ Add</button>
                </div>
                {form.ports.map((p, i) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6, alignItems: 'center' }}>
                    <input className="adw-entry" style={{ flex: 1 }} placeholder="Host port" value={p.host} onChange={e => updateRow('ports', i, 'host', e.target.value)}/>
                    <span style={{ color: 'var(--window-fg-color)', opacity: 0.4 }}>→</span>
                    <input className="adw-entry" style={{ flex: 1 }} placeholder="Container port" value={p.container} onChange={e => updateRow('ports', i, 'container', e.target.value)}/>
                    <button className="adw-row-btn danger" onClick={() => removeRow('ports', i)}><Ico n="trash" size={14}/></button>
                  </div>
                ))}
              </div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                  <label className="adw-entry-label" style={{ flex: 1, marginBottom: 0 }}>Volume Mounts</label>
                  <button className="adw-btn adw-btn--flat" style={{ height: 28, padding: '0 10px', fontSize: '0.8125rem' }} onClick={() => addRow('volumes')}>+ Add</button>
                </div>
                {form.volumes.map((v, i) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6, alignItems: 'center' }}>
                    <input className="adw-entry" style={{ flex: 1 }} placeholder="Volume / path" value={v.vol} onChange={e => updateRow('volumes', i, 'vol', e.target.value)}/>
                    <span style={{ color: 'var(--window-fg-color)', opacity: 0.4 }}>:</span>
                    <input className="adw-entry" style={{ flex: 1 }} placeholder="Mount path" value={v.mount} onChange={e => updateRow('volumes', i, 'mount', e.target.value)}/>
                    <button className="adw-row-btn danger" onClick={() => removeRow('volumes', i)}><Ico n="trash" size={14}/></button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                <label className="adw-entry-label" style={{ flex: 1, marginBottom: 0 }}>Environment Variables</label>
                <button className="adw-btn adw-btn--flat" style={{ height: 28, padding: '0 10px', fontSize: '0.8125rem' }} onClick={() => addRow('env')}>+ Add</button>
              </div>
              {form.env.map((e, i) => (
                <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6, alignItems: 'center' }}>
                  <input className="adw-entry" style={{ flex: 1 }} placeholder="KEY" value={e.k} onChange={x => updateRow('env', i, 'k', x.target.value)}/>
                  <span style={{ color: 'var(--window-fg-color)', opacity: 0.4 }}>=</span>
                  <input className="adw-entry" style={{ flex: 1 }} placeholder="value" value={e.v} onChange={x => updateRow('env', i, 'v', x.target.value)}/>
                  <button className="adw-row-btn danger" onClick={() => removeRow('env', i)}><Ico n="trash" size={14}/></button>
                </div>
              ))}
              <div style={{ marginTop: 12, padding: '10px 12px', background: 'rgba(38,162,105,0.1)', borderRadius: 8, fontSize: '0.8125rem', color: 'var(--success-color)' }}>
                Ready — <strong>{form.name || form.image.split(':')[0]}</strong> from <strong>{form.image}</strong>
                {form.ports.filter(p => p.host).length > 0 && ` · ${form.ports.filter(p => p.host).length} port(s)`}
              </div>
            </div>
          )}
        </div>
        <div className="adw-dialog__footer">
          <button className="adw-btn" onClick={step === 0 ? onClose : () => setStep(s => s - 1)}>{step === 0 ? 'Cancel' : 'Back'}</button>
          {step < steps.length - 1
            ? <button className="adw-btn adw-btn--suggested" disabled={!canNext[step]} onClick={() => setStep(s => s + 1)}>Next</button>
            : <button className="adw-btn adw-btn--suggested" onClick={() => { onDone && onDone(form); onClose(); }}>Create</button>}
        </div>
      </div>
    </div>
  );
};

// ─── Create Volume Dialog ─────────────────────────────────────────────────────
const CreateVolumeDialog = ({ onClose, onDone }) => {
  const { useState } = React;
  const [name, setName] = useState('');
  const [driver, setDriver] = useState('local');
  return (
    <div className="adw-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="vol-dlg-title">
      <div className="adw-dialog" style={{ maxWidth: 360 }} onClick={e => e.stopPropagation()}>
        <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
          <h2 className="adw-dialog__title" id="vol-dlg-title">Create Volume</h2>
          <IconBtn n="close" size={16} onClick={onClose}/>
        </div>
        <div className="adw-dialog__body">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label className="adw-entry-label">Name</label>
              <input className="adw-entry" placeholder="my-volume" value={name} onChange={e => setName(e.target.value)} autoFocus/>
            </div>
            <div>
              <label className="adw-entry-label">Driver</label>
              <select className="adw-entry" value={driver} onChange={e => setDriver(e.target.value)}>
                {['local', 'nfs', 'tmpfs'].map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
        </div>
        <div className="adw-dialog__footer">
          <button className="adw-btn" onClick={onClose}>Cancel</button>
          <button className="adw-btn adw-btn--suggested" disabled={!name.trim()}
            onClick={() => { onDone && onDone({ name: name.trim(), driver, mountpoint: `/var/lib/docker/volumes/${name}/_data`, size: '0 B', inUse: false }); onClose(); }}>
            Create
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Create Network Dialog ────────────────────────────────────────────────────
const CreateNetworkDialog = ({ onClose, onDone }) => {
  const { useState } = React;
  const [name, setName] = useState('');
  const [driver, setDriver] = useState('bridge');
  const [subnet, setSubnet] = useState('');
  return (
    <div className="adw-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="net-dlg-title">
      <div className="adw-dialog" style={{ maxWidth: 360 }} onClick={e => e.stopPropagation()}>
        <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
          <h2 className="adw-dialog__title" id="net-dlg-title">Create Network</h2>
          <IconBtn n="close" size={16} onClick={onClose}/>
        </div>
        <div className="adw-dialog__body">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label className="adw-entry-label">Name</label>
              <input className="adw-entry" placeholder="my-network" value={name} onChange={e => setName(e.target.value)} autoFocus/>
            </div>
            <div>
              <label className="adw-entry-label">Driver</label>
              <select className="adw-entry" value={driver} onChange={e => setDriver(e.target.value)}>
                {['bridge', 'overlay', 'macvlan', 'ipvlan'].map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="adw-entry-label">Subnet <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>(optional)</span></label>
              <input className="adw-entry" placeholder="172.20.0.0/16" value={subnet} onChange={e => setSubnet(e.target.value)}/>
            </div>
          </div>
        </div>
        <div className="adw-dialog__footer">
          <button className="adw-btn" onClick={onClose}>Cancel</button>
          <button className="adw-btn adw-btn--suggested" disabled={!name.trim()}
            onClick={() => { onDone && onDone({ id: 'new-' + Date.now(), name: name.trim(), driver, subnet: subnet || '172.20.0.0/16', gateway: '172.20.0.1', internal: false, containers: 0 }); onClose(); }}>
            Create
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Preferences Dialog ───────────────────────────────────────────────────────
const PreferencesDialog = ({ onClose, tweaks, setTweak, onPrune }) => {
  const { useState } = React;
  const [refreshInterval, setRefreshInterval] = useState('30');
  const [restartPolicy, setRestartPolicy]     = useState('unless-stopped');
  const [stopTimeout, setStopTimeout]         = useState('10');

  const SegControl = ({ value, options, onChange }) => (
    <div style={{ display: 'flex', background: 'rgba(128,128,128,0.12)', borderRadius: 6, padding: 2, gap: 2 }}>
      {options.map(o => (
        <button key={o.value} onClick={() => onChange(o.value)} style={{
          flex: 1, padding: '4px 10px', borderRadius: 4, border: 'none', cursor: 'pointer',
          fontFamily: 'var(--font)', fontSize: '0.8125rem', fontWeight: value === o.value ? 700 : 400,
          background: value === o.value ? 'var(--card-bg-color)' : 'transparent',
          color: 'var(--window-fg-color)',
          opacity: value === o.value ? 1 : 0.55,
          boxShadow: value === o.value ? 'var(--shadow-elevated-1)' : 'none',
          transition: 'all 0.12s', whiteSpace: 'nowrap',
        }}>{o.label}</button>
      ))}
    </div>
  );

  const PrefSelect = ({ value, options, onChange }) => (
    <select
      className="adw-entry"
      value={value}
      onChange={e => onChange(e.target.value)}
      style={{ width: 'auto', minWidth: 140, padding: '4px 8px', height: 32, fontSize: '0.875rem' }}
    >
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );

  const PrefRow = ({ label, children }) => (
    <div className="adw-pref-row" style={{ justifyContent: 'space-between', gap: 16 }}>
      <span className="adw-pref-row__key" style={{ width: 'auto', flex: 1 }}>{label}</span>
      <div style={{ flexShrink: 0 }}>{children}</div>
    </div>
  );

  return (
    <div className="adw-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="prefs-title">
      <div className="adw-dialog" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
        <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
          <h2 className="adw-dialog__title" id="prefs-title">Preferences</h2>
          <IconBtn n="close" size={16} onClick={onClose}/>
        </div>

        <div className="adw-dialog__body" style={{ display: 'flex', flexDirection: 'column', gap: 24, padding: '16px 20px 20px' }}>

          {/* General */}
          <div className="adw-prefs-group">
            <div className="adw-prefs-group__header">
              <h3 className="adw-prefs-group__title">General</h3>
            </div>
            <div className="adw-prefs-group__listbox">
              <PrefRow label="Theme">
                <SegControl
                  value={tweaks.theme}
                  options={[{ value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }]}
                  onChange={v => setTweak('theme', v)}
                />
              </PrefRow>
              <PrefRow label="Runtime">
                <SegControl
                  value={tweaks.runtime}
                  options={[
                    { value: 'docker', label: 'Docker' },
                    { value: 'podman', label: 'Podman' },
                    { value: 'containerd', label: 'containerd' },
                  ]}
                  onChange={v => setTweak('runtime', v)}
                />
              </PrefRow>
              <PrefRow label="Refresh interval">
                <PrefSelect
                  value={refreshInterval}
                  options={[
                    { value: '5',  label: '5 seconds'  },
                    { value: '15', label: '15 seconds' },
                    { value: '30', label: '30 seconds' },
                    { value: '60', label: '1 minute'   },
                  ]}
                  onChange={setRefreshInterval}
                />
              </PrefRow>
            </div>
          </div>

          {/* Container Defaults */}
          <div className="adw-prefs-group">
            <div className="adw-prefs-group__header">
              <h3 className="adw-prefs-group__title">Container Defaults</h3>
            </div>
            <div className="adw-prefs-group__listbox">
              <PrefRow label="Restart policy">
                <PrefSelect
                  value={restartPolicy}
                  options={[
                    { value: 'no',             label: 'No'             },
                    { value: 'always',         label: 'Always'         },
                    { value: 'unless-stopped', label: 'Unless stopped' },
                    { value: 'on-failure',     label: 'On failure'     },
                  ]}
                  onChange={setRestartPolicy}
                />
              </PrefRow>
              <PrefRow label="Stop timeout">
                <PrefSelect
                  value={stopTimeout}
                  options={[
                    { value: '5',  label: '5 seconds'  },
                    { value: '10', label: '10 seconds' },
                    { value: '30', label: '30 seconds' },
                    { value: '60', label: '60 seconds' },
                  ]}
                  onChange={setStopTimeout}
                />
              </PrefRow>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="adw-prefs-group">
            <div className="adw-prefs-group__header">
              <h3 className="adw-prefs-group__title">Danger Zone</h3>
            </div>
            <div className="adw-prefs-group__listbox">
              <div className="adw-pref-row" style={{ justifyContent: 'space-between', gap: 16 }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2, flex: 1 }}>
                  <span style={{ fontSize: '0.9375rem', color: 'var(--card-fg-color)' }}>Prune unused resources</span>
                  <span style={{ fontSize: '0.8125rem', color: 'var(--card-fg-color)', opacity: 0.55 }}>
                    Remove stopped containers, dangling images and unused networks
                  </span>
                </div>
                <button
                  className="adw-btn adw-btn--destructive"
                  style={{ flexShrink: 0, height: 32, padding: '0 14px', fontSize: '0.875rem' }}
                  onClick={() => { onClose(); onPrune && onPrune(); }}
                >
                  <Ico n="trash" size={14}/> Prune…
                </button>
              </div>
            </div>
          </div>

        </div>

        <div className="adw-dialog__footer">
          <button className="adw-btn adw-btn--suggested" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

// ─── Menu Popover ─────────────────────────────────────────────────────────────
const MenuPopover = ({ onClose, onAbout, onPrune, onSettings }) => {
  const { useEffect } = React;
  useEffect(() => {
    const h = () => onClose();
    setTimeout(() => window.addEventListener('click', h), 0);
    return () => window.removeEventListener('click', h);
  }, []);
  return (
    <div className="adw-menu" onClick={e => e.stopPropagation()} role="menu">
      <button className="adw-menu__item" role="menuitem" onClick={() => { onPrune(); onClose(); }}><Ico n="trash" size={16}/> Prune System…</button>
      <button className="adw-menu__item" role="menuitem" onClick={() => { onSettings && onSettings(); onClose(); }}><Ico n="settings" size={16}/> Preferences</button>
      <div className="adw-menu__sep" role="separator"/>
      <button className="adw-menu__item" role="menuitem" onClick={() => { onAbout(); onClose(); }}><Ico n="info" size={16}/> About Doca</button>
    </div>
  );
};

// ─── About Dialog ─────────────────────────────────────────────────────────────
const AboutDialog = ({ onClose }) => (
  <div className="adw-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="about-title">
    <div className="adw-dialog" style={{ maxWidth: 380 }} onClick={e => e.stopPropagation()}>
      <div className="adw-dialog__header" style={{ justifyContent: 'space-between' }}>
        <h2 className="adw-dialog__title" id="about-title">About Doca</h2>
        <IconBtn n="close" size={16} onClick={onClose}/>
      </div>
      <div className="adw-dialog__body" style={{ display: 'flex', flexDirection: 'column', gap: 20, padding: '16px 20px 20px' }}>
        {/* Hero */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, textAlign: 'center' }}>
          <div className="adw-about__icon">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
              <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
              <line x1="12" y1="22.08" x2="12" y2="12"/>
            </svg>
          </div>
          <div>
            <p style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--window-fg-color)' }}>Doca</p>
            <p style={{ fontSize: '0.875rem', color: 'var(--window-fg-color)', opacity: 0.55 }}>Version 0.3.0 (build 20260501)</p>
          </div>
          <p style={{ fontSize: '0.9375rem', color: 'var(--window-fg-color)', opacity: 0.7, maxWidth: 280, textWrap: 'pretty' }}>
            A native GNOME application for managing Docker, Podman, and containerd containers.
          Built with GTK 4 and libadwaita.
          </p>
        </div>

        {/* Details */}
        <div className="adw-prefs-group">
          <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Details</h3></div>
          <div className="adw-prefs-group__listbox">
            <PR k="Runtime"    v="Docker 27.0.1"/>
            <PR k="GTK"        v="4.14.1"/>
            <PR k="libadwaita" v="1.5.0"/>
            <PR k="Platform"   v="Linux x86_64"/>
          </div>
        </div>

        {/* Links */}
        <div className="adw-prefs-group">
          <div className="adw-prefs-group__header"><h3 className="adw-prefs-group__title">Links</h3></div>
          <div className="adw-prefs-group__listbox">
            <a className="adw-pref-row" href="#" onClick={e => e.preventDefault()} style={{ cursor: 'pointer', color: 'var(--accent-color)', textDecoration: 'none', gap: 10 }}>
              <Ico n="compose" size={16}/> <span style={{ fontSize: '0.9375rem' }}>Source Code on GitHub</span>
            </a>
            <a className="adw-pref-row" href="#" onClick={e => e.preventDefault()} style={{ cursor: 'pointer', color: 'var(--accent-color)', textDecoration: 'none', gap: 10, borderBottom: 'none' }}>
              <Ico n="warn" size={16}/> <span style={{ fontSize: '0.9375rem' }}>Report an Issue</span>
            </a>
          </div>
        </div>

        <p style={{ fontSize: '0.75rem', color: 'var(--window-fg-color)', opacity: 0.45, textAlign: 'center', lineHeight: 1.6 }}>
          Released under the <strong>GNU General Public License v3.0</strong>.<br/>© 2026 Doca Contributors.
        </p>
      </div>
    </div>
  </div>
);

Object.assign(window, {
  ConfirmDialog, PullImageDialog, CreateContainerWizard,
  CreateVolumeDialog, CreateNetworkDialog, MenuPopover, AboutDialog,
  PreferencesDialog,
});
